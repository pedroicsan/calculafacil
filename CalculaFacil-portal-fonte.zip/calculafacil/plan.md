# Plano de implementação — CalculaFácil

## Escopo e decisões principais

Construirei um portal público em português brasileiro, rápido, responsivo e portátil, sem servidor de aplicação, banco de dados, login, chamadas de IA, APIs de terceiros, bibliotecas pagas, assinaturas ou dependências de hospedagem Manus. As calculadoras serão executadas integralmente no navegador; taxas, preços, distâncias, consumo e demais dados variáveis serão informados pelo visitante, sem valores presumidos. Não haverá gravação ou envio dos valores calculados.

A implementação será um site estático pré-gerado: HTML semântico por página, CSS e JavaScript nativos, com Python da biblioteca padrão apenas para montar as páginas e gerar arquivos de SEO. Não serão necessárias dependências externas para instalar ou executar o portal. Cada URL será um arquivo HTML real para leitura por mecanismos de busca; caminhos amigáveis terminarão em diretórios com `index.html`, compatíveis com GitHub Pages.

## Estrutura e navegação

A página inicial apresentará pesquisa local, ferramentas populares, categorias e acesso ao catálogo completo. Cada uma das 15 calculadoras terá sua própria página com título e descrição exclusivos, instruções originais, campos claros, atualização instantânea, validação e explicação da fórmula. As páginas de categoria agruparão as ferramentas por assunto. Também haverá páginas Sobre, Contato, Política de Privacidade e Termos de Uso, além de navegação e links internos relacionados.

As categorias iniciais serão Casa e energia; Compras e preços; Finanças do dia a dia; Viagens; e Conversões. As ferramentas solicitadas serão: consumo de energia; combustível para viagem; comparação de preço por kg/litro/unidade; descontos; porcentagem; salário por hora; divisão de despesas; economia mensal; conversor de medidas; custo de eletrodomésticos; aumento/redução percentual; juros simples; custo de viagem; economia entre produtos; preço por quantidade.

Uma fonte de dados central manterá nomes, categorias, explicações, fórmulas e metadados. Um gerador Python criará `dist/` com todas as páginas e recursos finais; os arquivos-fonte, os arquivos gerados necessários e as instruções serão incluídos na cópia portátil do projeto. Os arquivos principais serão organizados entre `src/` (dados, modelos, estilos e lógica de cálculo), `scripts/` (geração e configuração), `tests/`, `dist/` (site pronto para servir), `.github/workflows/` (publicação gratuita opcional) e `README.md` (uso e implantação).

## Cálculos e experiência

A lógica de cálculo ficará separada da apresentação e será coberta por testes sem dependências externas. As páginas tratarão campos vazios, números inválidos, decimais, limites impossíveis, divisão por zero e arredondamento monetário de forma explícita. Quando uma operação usar tarifa, preço ou consumo, o usuário informará o valor. O resultado exibirá unidade, arredondamento e uma explicação direta da fórmula aplicada.

O conversor abrangerá unidades comuns de comprimento, massa e volume, além de temperatura. As ferramentas de viagem distinguirão combustível, custos adicionais e total da viagem; comparadores destacarão a alternativa de menor custo normalizado. A ferramenta de divisão mostrará a cota individual, e a de economia mensal estimará o tempo até a meta a partir dos valores informados.

## Identidade visual e interação

A direção visual seguirá o briefing de portal de utilidades digitais: confiável, amigável e orientado à tarefa. A paleta solicitada será preservada: azul `#1769AA`, azul escuro `#103B63`, branco `#FFFFFF`, cinza claro `#F4F6F8` e verde `#16865B` para resultados positivos. O desenho será editorial e funcional: cabeçalho simples, pesquisa destacada, listas por categoria e cartões/linhas compactos; em cada calculadora, o formulário e o painel de resultado terão prioridade, sem excesso de elementos decorativos. No celular, a leitura e os controles passarão a uma coluna.

A marca terá um símbolo vetorial próprio baseado nas letras C/F e em sinais de cálculo, sem imagens externas. Tipografia do sistema evitará downloads de fontes. Estados de foco serão visíveis, controles terão rótulos acessíveis e contraste adequado, e animações serão discretas, rápidas e respeitarão `prefers-reduced-motion`. A voz será direta e didática, por exemplo: “Informe seus dados e veja o custo estimado” e “A conta fica por sua conta — os valores ficam neste aparelho”.

## SEO, acessibilidade e funcionamento offline

Todas as páginas estáticas terão HTML inicial com conteúdo útil, `title`, descrição, H1 e dados estruturados adequados (página, trilha de navegação e ferramenta quando aplicável), além de links internos. O gerador criará `sitemap.xml` e `robots.txt` para o endereço público real escolhido. Não colocarei URLs canônicas ou de compartilhamento inventadas: o fluxo de publicação do GitHub Pages poderá derivar o domínio e o caminho do repositório; em outra hospedagem, o usuário informará a origem real antes de gerar a versão de produção.

Um manifesto e um service worker nativos poderão armazenar páginas e recursos estáticos para acesso após o primeiro carregamento; a primeira visita ainda requer internet. Não serão armazenados dados dos cálculos. A política explicará esse comportamento e avisará que anúncios ou analytics futuros exigem atualização da política.

## Custo zero, publicação e valores a configurar

Não publicarei o portal em hospedagem Manus paga ou baseada em consumo. Incluirei um fluxo opcional de GitHub Pages com GitHub Actions e instruções para ativá-lo a partir de uma conta/repositório público gratuito; não comprarei domínio nem contratarei serviço. Primeiro entregarei uma cópia ZIP completa e o README para independência. A publicação efetiva em uma conta GitHub depende de autorização/conexão da conta e da escolha do repositório; se isso não estiver disponível nesta sessão, os passos manuais ficarão documentados.

Contato não será enviado por um formulário sem servidor. O endereço de e-mail do responsável será configurável e ficará vazio até ser fornecido; não inventarei contato. Também deixarei em branco os identificadores opcionais de Google Analytics/Search Console e AdSense. Analytics e anúncios não serão carregados enquanto não forem configurados com identificadores/códigos legítimos; espaços publicitários serão identificados como reservados, nunca como anúncios reais. Links de afiliados não serão inventados.

## Fluxo de construção

Após a aprovação deste plano, criarei os critérios de entrega do projeto, implementarei o gerador e as páginas, executarei os testes automatizados das fórmulas e das entradas inválidas, conferirei as rotas e os arquivos de SEO gerados, e abrirei o Preview para verificar o resultado em desktop e celular. Corrigirei problemas encontrados, prepararei o arquivo ZIP com fontes e instruções, e deixarei o fluxo de GitHub Pages pronto. A versão só será divulgada publicamente em hospedagem gratuita depois de a conta/repositório estarem autorizados e configurados; o Preview não será apresentado como site publicado.

## Fase 2 — plano aditivo aprovado pelo usuário

Preservar o portal existente, a identidade visual, os 15 calculadores e a publicação atual em GitHub Pages; não reconstruir o site, não trocar framework nem remover funcionalidades. A única publicação desta fase será atualização do repositório público já autorizado `pedroicsan/calculafacil`, depois de build e testes locais concluídos. Não fazer push do projeto para outro host nem contratar serviços.

Auditar individualmente as 15 páginas existentes por meio de pesquisa independente e devolver para cada uma: palavra-chave principal e termos secundários, título e descrição alinhados à intenção, introdução original, instruções de uso, fórmula com exemplos calculados, casos de uso, perguntas e respostas exclusivas e links internos pertinentes. Confirmar o conteúdo contra a função matemática implementada; não fabricar volume de busca, perguntas do Google, dados, exemplos incorretos ou texto genérico para alongar a página. Gravar FAQ por ferramenta como dados próprios e fazê-lo aparecer no HTML estático e na navegação da página.

Pesquisar oportunidades além das 15 ferramentas. Implementar somente ferramentas que resolvam necessidades distintas com intenção de busca plausível, fórmula transparente, dados fornecidos pelo visitante, cálculo local e conteúdo/SEO individual; não adicionar ferramentas de saúde, fiscais ou jurídicas com risco/complexidade desnecessária, não inventar valores padrão e não duplicar intenção das páginas atuais. Registrar razões, consultas investigadas e fontes.

Conferir todas as rotas públicas existentes e novas quanto a indexabilidade, HTML inicial completo, URL legível, canonical absoluto correto, sitemap real, robots, títulos/descrições exclusivos, H1/H2/H3, breadcrumbs quando úteis, links internos, dados estruturados válidos e fiéis, atributos alt e tamanho das imagens, navegação/404, acessibilidade, mobile e velocidade/Core Web Vitals. Não adicionar avaliação, estrelas, comentários, autoria ou estatísticas não verificadas; não usar dados estruturados que não representem o conteúdo real.

Revisar os espaços AdSense existentes: adaptáveis, com rótulo “Publicidade”, disponíveis somente após aprovação e IDs legítimos, sem excesso no celular, sem proximidade que induza clique acidental e sem interferir nos campos/resultado. Manter desativado agora; documentar aprovação, configuração dos IDs reais e revisão da política de privacidade quando/antes da ativação. Revisar afiliados: estrutura contextual, rotulagem comercial, `rel="sponsored"`, vazia até o proprietário fornecer URLs válidas; não inventar empresa, produto, preço, comissão ou parceria. Criar `/anuncie-no-calculafacil/` com formatos potenciais e contato só se `contactEmail` verdadeiro estiver configurado; não alegar audiência ou resultados. Documentar ideias realistas de planilhas e materiais educativos sem checkout, pagamento ou assinatura.

Documentar Search Console (verificação com valor legítimo e envio do sitemap) e Analytics opcional com consentimento; não inventar ID nem carregar rastreamento sem configuração e consentimento. Melhorar somente navegação de retenção legítima: recomendações relevantes, ferramentas populares, categorias, busca funcional, explicações e resultados claros; sem pop-ups ou notificações invasivas.

Preservar custo recorrente zero, operação sem servidor/API/IA/login/banco de dados e publicação gratuita no GitHub Pages. Todas as calculadoras continuam funcionando com anúncios, afiliados e Analytics desativados. Antes de publicar, rodar fórmulas, campos vazios/inválidos/decimais, links, 404, sitemap/robots, metadados, build completo e workflow de Pages; corrigir falhas e publicar somente após aprovação desses resultados. Entregar relatório final com os 16 itens solicitados, distinguindo implementado, preparado e dependente do proprietário.

Estrutura incremental prevista: `src/data/tools.json` recebe termos de busca, conteúdo original e FAQ próprio por ferramenta; `src/data/categories.json` recebe categorias somente se houver novas ferramentas justificadas; `src/js/calculators.mjs`/`src/js/app.mjs` recebem fórmulas e renderização locais; `scripts/build_site.py` renderiza FAQs, nova página de patrocínio, metadados e rotas estáticas; `tests/` cobre novas fórmulas, HTML/SEO e configurações; `docs/` recebe fontes, checklist de monetização, oportunidades digitais e relatório da Fase 2. O ZIP-fonte atual será substituído somente depois da validação e o workflow existente é o único mecanismo de implantação pública.
