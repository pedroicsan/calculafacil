import test from "node:test";
import assert from "node:assert/strict";
import { calculate, getUnitOptions } from "../src/js/calculators.mjs";

const closeTo = (actual, expected, tolerance = 1e-9) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} is not within ${tolerance} of ${expected}`);

const cases = [
  ["energy", { powerW: 1000, hoursPerDay: 2, daysPerMonth: 30, pricePerKwh: 0.8 }, [60, 48]],
  ["fuel", { distanceKm: 150, tripCount: 2, kmPerLiter: 15, fuelPrice: 6 }, [300, 20, 120]],
  ["priceCompare", { priceA: 12, quantityA: 500, unitA: "g", priceB: 20, quantityB: 1, unitB: "kg" }, [24, 20, 20]],
  ["discount", { originalPrice: 200, percentDiscount: 10, fixedDiscount: 30 }, [180, 20, 170, 30]],
  ["percentage", { percentage: 15, baseValue: 240 }, [36]],
  ["hourlySalary", { monthlySalary: 3200, monthlyHours: 160 }, [20, 3200, 160]],
  ["expenseSplit", { totalExpenses: 375, participants: 3 }, [125, 375, 3]],
  ["monthlySavings", { targetAmount: 1000, currentSavings: 250, monthlyDeposit: 200 }, [4, 750, 1050]],
  ["unitConverter", { category: "length", value: 2.5, fromUnit: "km", toUnit: "m" }, [2500]],
  ["applianceCost", { powerW: 1500, hoursPerDay: 1, daysPerMonth: 20, pricePerKwh: 0.75 }, [30, 22.5]],
  ["percentChange", { baseValue: 80, changePercent: 25, direction: "increase" }, [20, 100, 80]],
  ["simpleInterest", { principal: 1000, ratePercent: 2, periods: 6, periodName: "meses" }, [120, 1120]],
  ["tripCost", { distanceKm: 300, kmPerLiter: 15, fuelPrice: 6, tolls: 30, lodging: 0, food: 80, otherCosts: 10 }, [120, 120, 240, 20]],
  ["productSavings", { priceA: 100, shippingA: 20, priceB: 115, shippingB: 0 }, [120, 115, 5]],
  ["priceQuantity", { packagePrice: 18, packageQuantity: 750, quantityUnit: "g", desiredQuantity: 250 }, [24, 6]]
];

test("all 15 calculator types return the expected numeric results", () => {
  for (const [type, input, expected] of cases) {
    const result = calculate(type, input);
    assert.ok(result.summary, `${type} should have a summary`);
    const actual = result.metrics.map((item) => item.value);
    assert.equal(actual.length, expected.length, `${type} metric count`);
    expected.forEach((number, index) => closeTo(actual[index], number));
  }
});

test("mass, volume and count comparisons use correct base units", () => {
  const mass = calculate("priceCompare", { priceA: 5, quantityA: 250, unitA: "g", priceB: 18, quantityB: 1, unitB: "kg" });
  closeTo(mass.metrics[0].value, 20);
  closeTo(mass.metrics[1].value, 18);
  const volume = calculate("priceCompare", { priceA: 3, quantityA: 500, unitA: "ml", priceB: 5, quantityB: 1, unitB: "L" });
  closeTo(volume.metrics[0].value, 6);
  closeTo(volume.metrics[1].value, 5);
  const count = calculate("priceCompare", { priceA: 8, quantityA: 4, unitA: "un", priceB: 5, quantityB: 2, unitB: "un" });
  closeTo(count.metrics[0].value, 2);
  closeTo(count.metrics[1].value, 2.5);
});

test("temperature conversions and supported unit lists are correct", () => {
  const freezing = calculate("unitConverter", { category: "temperature", value: 32, fromUnit: "F", toUnit: "C" });
  closeTo(freezing.metrics[0].value, 0);
  const boiling = calculate("unitConverter", { category: "temperature", value: 100, fromUnit: "C", toUnit: "F" });
  closeTo(boiling.metrics[0].value, 212);
  assert.equal(getUnitOptions("mass").length, 5);
  assert.throws(() => calculate("unitConverter", { category: "temperature", value: -274, fromUnit: "C", toUnit: "K" }), /zero kelvin/);
  assert.throws(() => calculate("unitConverter", { category: "temperature", value: -1, fromUnit: "K", toUnit: "C" }), /Kelvin não pode ser menor que zero/);
});

test("optional values, decimal commas, caps and ties are handled", () => {
  assert.equal(calculate("monthlySavings", { targetAmount: 100, currentSavings: 120, monthlyDeposit: 0 }).metrics[0].value, 0);
  assert.equal(calculate("discount", { originalPrice: 50, percentDiscount: 0, fixedDiscount: 0 }).metrics[0].value, 50);
  assert.equal(calculate("discount", { originalPrice: 50, percentDiscount: 10, fixedDiscount: 90 }).metrics[2].value, 0);
  assert.equal(calculate("productSavings", { priceA: 40, priceB: 40 }).summary, "As duas opções têm o mesmo custo.");
  closeTo(calculate("percentage", { percentage: "12,5", baseValue: "80,5" }).metrics[0].value, 10.0625);
  assert.equal(calculate("percentChange", { baseValue: 100, changePercent: 150, direction: "increase" }).metrics[1].value, 250);
});

test("invalid, empty and incompatible fields produce clear errors", () => {
  assert.throws(() => calculate("energy", { powerW: 100, hoursPerDay: 25, daysPerMonth: 10, pricePerKwh: 1 }), /não pode ser maior que 24/);
  assert.throws(() => calculate("fuel", { distanceKm: 100, tripCount: 1, kmPerLiter: 0, fuelPrice: 5 }), /maior ou igual/);
  assert.throws(() => calculate("priceCompare", { priceA: 1, quantityA: 1, unitA: "kg", priceB: 1, quantityB: 1, unitB: "L" }), /mesma família/);
  assert.throws(() => calculate("expenseSplit", { totalExpenses: 30, participants: 0 }), /maior ou igual a 1/);
  assert.throws(() => calculate("monthlySavings", { targetAmount: 500, currentSavings: 0, monthlyDeposit: 0 }), /maior que zero/);
  assert.throws(() => calculate("unitConverter", { category: "length", value: 1, fromUnit: "m", toUnit: "g" }), /categoria e as unidades selecionadas/);
  assert.throws(() => calculate("percentage", { baseValue: 50 }), /Informe a porcentagem/);
  assert.throws(() => calculate("percentage", { percentage: "não é número", baseValue: 50 }), /número válido/);
  assert.throws(() => calculate("percentChange", { baseValue: 100, changePercent: 101, direction: "decrease" }), /não pode ultrapassar 100%/);
  assert.throws(() => calculate("tripCost", { distanceKm: 10, kmPerLiter: 10, fuelPrice: 5, tolls: -1 }), /zero ou maior/);
});
