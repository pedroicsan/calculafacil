import json
import tempfile
import unittest
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path

from scripts.build_site import build_site

ROOT = Path(__file__).resolve().parents[1]
TEST_ORIGIN = "https://www.example.test"
TEST_BASE = "/calculafacil"


class PageInspector(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.lang = ""
        self.title = ""
        self.meta = {}
        self.canonical = ""
        self.base = ""
        self.open_graph = {}
        self.links = []
        self.h1 = []
        self.h2 = []
        self.body_text = []
        self.jsonld = []
        self.calculators = []
        self.search_cards = 0
        self._in_title = False
        self._heading = None
        self._in_body = False
        self._in_jsonld = False
        self._jsonld_text = []
        self._current_form = None

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "html":
            self.lang = values.get("lang", "")
        elif tag == "body":
            self._in_body = True
        elif tag == "title":
            self._in_title = True
        elif tag == "base":
            self.base = values.get("href", "")
        elif tag == "meta":
            name = values.get("name") or ""
            prop = values.get("property") or ""
            if name:
                self.meta[name.lower()] = values.get("content", "")
            if prop.startswith("og:"):
                self.open_graph[prop] = values.get("content", "")
        elif tag == "link" and values.get("rel") == "canonical":
            self.canonical = values.get("href", "")
        elif tag == "a" and values.get("href"):
            self.links.append(values["href"])
        elif tag in ("h1", "h2"):
            self._heading = tag
            if tag == "h1":
                self.h1.append("")
            else:
                self.h2.append("")
        elif tag == "script" and values.get("type") == "application/ld+json":
            self._in_jsonld = True
            self._jsonld_text = []
        elif tag == "form" and "data-calculator-form" in values:
            self._current_form = {"type": values.get("data-calculator-type", ""), "fields": set(), "novalidate": "novalidate" in values}
            self.calculators.append(self._current_form)
        elif tag in ("input", "select", "textarea") and self._current_form is not None and values.get("name"):
            self._current_form["fields"].add(values["name"])
        if values.get("data-search-card") is not None:
            self.search_cards += 1

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag in ("h1", "h2"):
            self._heading = None
        elif tag == "body":
            self._in_body = False
        elif tag == "script" and self._in_jsonld:
            self.jsonld.append("".join(self._jsonld_text))
            self._jsonld_text = []
            self._in_jsonld = False
        elif tag == "form":
            self._current_form = None

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if self._heading == "h1" and self.h1:
            self.h1[-1] += data
        elif self._heading == "h2" and self.h2:
            self.h2[-1] += data
        if self._in_body:
            self.body_text.append(data)
        if self._in_jsonld:
            self._jsonld_text.append(data)


def public_url(route):
    return TEST_ORIGIN + TEST_BASE + (route if route.startswith("/") else f"/{route}")


class GeneratedSiteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._temporary = tempfile.TemporaryDirectory(prefix=".calcafacil-test-", dir=ROOT)
        cls.output = Path(cls._temporary.name) / "production"
        cls.preview_output = Path(cls._temporary.name) / "preview"
        build_site(cls.output, TEST_ORIGIN, TEST_BASE)
        build_site(cls.preview_output, "", "")
        cls.routes = json.loads((cls.output / "manus-routes.json").read_text(encoding="utf-8"))["routes"]
        cls.pages = {}
        for route in cls.routes:
            page_path = cls.output / ("index.html" if route["path"] == "/" else f"{route['path'].strip('/')}/index.html")
            parser = PageInspector()
            parser.feed(page_path.read_text(encoding="utf-8"))
            cls.pages[route["path"]] = parser

    @classmethod
    def tearDownClass(cls):
        cls._temporary.cleanup()

    def test_all_25_routes_are_pre_rendered_with_unique_seo_metadata(self):
        self.assertEqual(len(self.routes), 25)
        self.assertEqual(len({item["path"] for item in self.routes}), 25)
        self.assertEqual(len({page.title for page in self.pages.values()}), 25)
        self.assertEqual(len({page.meta.get("description") for page in self.pages.values()}), 25)
        for route, page in self.pages.items():
            with self.subTest(route=route):
                self.assertEqual(page.lang, "pt-BR")
                self.assertTrue(30 <= len(page.title) <= 60, f"title length {len(page.title)}: {page.title}")
                description = page.meta.get("description", "")
                self.assertTrue(50 <= len(description) <= 160, f"description length {len(description)}: {description}")
                self.assertTrue(page.h1 and 0 < len(page.h1[0].strip()) <= 80)
                self.assertTrue(page.h2 and all(0 < len(item.strip()) <= 80 for item in page.h2))
                keywords = [item.strip() for item in page.meta.get("keywords", "").split(",") if item.strip()]
                self.assertTrue(3 <= len(keywords) <= 8)
                self.assertTrue(len(" ".join(page.body_text).strip()) > 150)
                self.assertEqual(page.canonical, public_url(route))
                self.assertEqual(page.open_graph.get("og:url"), public_url(route))
                self.assertEqual(page.open_graph.get("og:type"), "website")
                self.assertEqual(page.open_graph.get("og:site_name"), "CalculaFácil")
                self.assertTrue(page.open_graph.get("og:image", "").endswith("/assets/social-card.png"))
                self.assertEqual(page.meta.get("twitter:card"), "summary_large_image")
                self.assertTrue(page.meta.get("twitter:image", "").endswith("/assets/social-card.png"))
                self.assertEqual(page.meta.get("robots"), "index,follow")
                self.assertEqual(page.base, f"{TEST_BASE}/")
                self.assertTrue(page.jsonld)
                for block in page.jsonld:
                    json.loads(block)
                expected_skip = "./#main-content" if route == "/" else f"{route.strip('/')}/#main-content"
                self.assertIn(expected_skip, page.links)
                for link in page.links:
                    if link.startswith(("http://", "https://", "mailto:", "tel:", "#", "?")):
                        continue
                    self.assertFalse(link.startswith("/"), f"absolute root-relative link breaks project paths: {link}")

    def test_all_calculators_are_present_on_the_homepage_and_have_working_forms(self):
        home = self.pages["/"]
        homepage_tools = {link for link in home.links if link.startswith("ferramentas/")}
        self.assertEqual(len(homepage_tools), 15)
        tools = json.loads((ROOT / "src/data/tools.json").read_text(encoding="utf-8"))
        self.assertEqual(len(tools), 15)
        for tool in tools:
            route = f"/ferramentas/{tool['slug']}/"
            with self.subTest(tool=tool["slug"]):
                page = self.pages[route]
                self.assertEqual(len(page.calculators), 1)
                form = page.calculators[0]
                self.assertEqual(form["type"], tool["type"])
                self.assertTrue(form["novalidate"])
                self.assertTrue({field["name"] for field in tool["fields"]}.issubset(form["fields"]))
                self.assertGreaterEqual(len(page.h2), 2)
                self.assertTrue(any(f"ferramentas/{related}/" in link for link in page.links for related in tool["related"]))

    def test_categories_and_required_information_pages_exist(self):
        categories = json.loads((ROOT / "src/data/categories.json").read_text(encoding="utf-8"))
        self.assertEqual(len(categories), 5)
        for category in categories:
            self.assertIn(f"/categoria/{category['slug']}/", self.pages)
        for name in ("sobre", "contato", "privacidade", "termos"):
            self.assertIn(f"/{name}/", self.pages)
        privacy = (self.output / "privacidade/index.html").read_text(encoding="utf-8")
        self.assertIn("endereços IP", privacy)
        self.assertIn("docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages", privacy)

    def test_sitemap_robots_manifest_and_offline_cache_use_the_configured_project_path(self):
        namespace = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
        sitemap = ET.parse(self.output / "sitemap.xml").getroot()
        locations = [item.text for item in sitemap.findall("sm:url/sm:loc", namespace)]
        expected = [public_url(item["path"]) for item in self.routes]
        self.assertEqual(locations, expected)
        robots = (self.output / "robots.txt").read_text(encoding="utf-8")
        self.assertIn("Allow: /", robots)
        self.assertIn(f"Sitemap: {TEST_ORIGIN}{TEST_BASE}/sitemap.xml", robots)
        manifest = json.loads((self.output / "manifest.webmanifest").read_text(encoding="utf-8"))
        self.assertEqual(manifest["start_url"], f"{TEST_BASE}/")
        self.assertEqual(manifest["scope"], f"{TEST_BASE}/")
        self.assertEqual({item["sizes"] for item in manifest["icons"]}, {"192x192", "512x512"})
        for icon in manifest["icons"]:
            self.assertTrue((self.output / icon["src"]).is_file())
        worker = (self.output / "sw.js").read_text(encoding="utf-8")
        self.assertRegex(worker, r'const CACHE_NAME = "calculafacil-[0-9a-f]{12}";')
        import re
        match = re.search(r"const PRECACHE_URLS = (.*);", worker)
        if match is None:
            self.fail("the generated service worker has no preload route list")
        precache = json.loads(match.group(1))
        for route in self.routes:
            self.assertIn("./" if route["path"] == "/" else f".{route['path']}", precache)
        self.assertIn("self.skipWaiting()", worker)

    def test_preview_has_no_guessed_public_urls_and_is_noindex(self):
        preview = PageInspector()
        preview.feed((self.preview_output / "index.html").read_text(encoding="utf-8"))
        self.assertEqual(preview.meta.get("robots"), "noindex,nofollow")
        self.assertFalse(preview.canonical)
        self.assertFalse(preview.open_graph.get("og:url"))
        self.assertFalse((self.preview_output / "sitemap.xml").exists())
        self.assertEqual((self.preview_output / "robots.txt").read_text(encoding="utf-8"), "User-agent: *\nDisallow: /\n")


if __name__ == "__main__":
    unittest.main()
