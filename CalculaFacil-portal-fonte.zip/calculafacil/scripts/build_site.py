#!/usr/bin/env python3
"""Generate the fully static CalculaFácil site using only Python's standard library."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from html import escape
from pathlib import Path
from urllib.parse import urlparse
from xml.sax.saxutils import escape as xml_escape

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
ASSETS = SRC / "assets"
DATA = SRC / "data"
TEMPLATES = SRC / "templates"


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def esc(value: object) -> str:
    return escape(str(value), quote=True)


def safe_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")


def normalize_origin(origin: str) -> str:
    origin = origin.strip().rstrip("/")
    if not origin:
        return ""
    parsed = urlparse(origin)
    if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
        raise ValueError("A origem pública precisa ser uma URL HTTPS real, sem credenciais, caminho, consulta ou fragmento.")
    if parsed.path not in ("", "/") or parsed.query or parsed.fragment:
        raise ValueError("Informe somente a origem, por exemplo https://site.example; o caminho-base é configurado separadamente.")
    return f"https://{parsed.netloc.lower()}"


def normalize_base_path(base_path: str) -> str:
    base_path = base_path.strip()
    if not base_path or base_path == "/":
        return ""
    if "\\" in base_path or any(ch.isspace() for ch in base_path) or "?" in base_path or "#" in base_path:
        raise ValueError("O caminho-base não pode conter espaços, barras invertidas, consultas ou fragmentos.")
    normalized = "/" + base_path.strip("/")
    if any(segment in ("", ".", "..") for segment in normalized[1:].split("/")):
        raise ValueError("O caminho-base contém um segmento inválido.")
    if not re.fullmatch(r"/[A-Za-z0-9._~-]+(?:/[A-Za-z0-9._~-]+)*", normalized):
        raise ValueError("Use somente letras, números, ponto, sublinhado, til e hífen no caminho-base.")
    return normalized


def canonical_for(origin: str, base_path: str, route: str) -> str:
    if not origin:
        return ""
    suffix = route.lstrip("/")
    return f"{origin}{base_path}/{suffix}" if suffix else f"{origin}{base_path}/"


def jsonld_script(data: dict) -> str:
    return f'<script type="application/ld+json">{safe_json(data)}</script>'


def category_icon(name: str) -> str:
    icons = {
        "home": '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-6h-4v6H4a1 1 0 0 1-1-1z"/><path d="M8 21v-6h8v6"/>',
        "tag": '<path d="M20.5 13.5 13 21l-10-10V3h8z"/><circle cx="7.5" cy="7.5" r="1.4"/>',
        "chart": '<path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 5-7"/><path d="M19 6h-4m4 0v4"/>',
        "route": '<circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="6" r="2.5"/><path d="M8.5 18H12a4 4 0 0 0 4-4v-4a4 4 0 0 1 4-4"/>',
        "arrows": '<path d="M7 7h13l-3-3M17 17H4l3 3"/><path d="M20 7v4M4 17v-4"/>'
    }
    body = icons.get(name, icons["chart"])
    return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{body}</svg>'


def render_category_card(category: dict, count: int) -> str:
    search = f'{category["name"]} {category["description"]}'
    return (
        f'<a class="category-card" href="categoria/{esc(category["slug"])}/" '
        f'data-search-card="{esc(search)}">'
        f'<span class="category-icon">{category_icon(category["icon"])}</span>'
        f'<strong>{esc(category["name"])}</strong>'
        f'<small>{count} {"ferramenta" if count == 1 else "ferramentas"}</small></a>'
    )


def tool_search_text(tool: dict, category_name: str) -> str:
    return " ".join([tool["name"], tool["short"], category_name, *tool.get("keywords", [])])


def render_tool_card(tool: dict, category_names: dict[str, str]) -> str:
    category_name = category_names.get(tool["category"], "Ferramentas")
    glyphs = {
        "energy": "kWh", "fuel": "R$", "priceCompare": "kg", "discount": "%",
        "percentage": "%", "hourlySalary": "/h", "expenseSplit": "÷", "monthlySavings": "↗",
        "unitConverter": "↔", "applianceCost": "kWh", "percentChange": "±", "simpleInterest": "i",
        "tripCost": "km", "productSavings": "−", "priceQuantity": "×", "paintQuantity": "L",
        "wallpaperRolls": "rol", "weightedMean": "x̄"
    }
    glyph = glyphs.get(tool["type"], "=")
    search = tool_search_text(tool, category_name)
    return (
        f'<a class="tool-card" href="ferramentas/{esc(tool["slug"])}/" '
        f'data-search-card="{esc(search)}">'
        f'<span class="tool-symbol" aria-hidden="true">{esc(glyph)}</span>'
        f'<span class="tool-card-copy"><strong>{esc(tool["name"])}</strong>'
        f'<span>{esc(tool["short"])}</span><small>{esc(category_name)}</small></span></a>'
    )


def render_search_empty() -> str:
    return '<p class="search-empty" data-search-empty role="status">Nenhuma ferramenta corresponde à pesquisa. Tente outro termo.</p>'


def render_ad_slot(site_config: dict, placement: str) -> str:
    client = str(site_config.get("adsenseClientId", "")).strip()
    slot = str(site_config.get("adsSlots", {}).get(placement, "")).strip()
    if site_config.get("adsEnabled") is True and re.fullmatch(r"ca-pub-\d{16}", client) and re.fullmatch(r"\d{5,20}", slot):
        return f'<aside class="ad-slot ad-slot-live" data-ad-zone="{esc(placement)}" data-ad-slot="{esc(slot)}" aria-label="Publicidade"><span class="ad-label">Publicidade</span></aside>'
    return '<aside class="ad-slot" aria-label="Publicidade"><span class="ad-label">Publicidade</span><span>Espaço reservado; não há anúncio ativo.</span></aside>'


def render_affiliate_links(site_config: dict, *, tool_slug: str = "", category_slug: str = "",
                           valid_tool_slugs: set[str] | None = None,
                           valid_category_slugs: set[str] | None = None) -> str:
    links = site_config.get("affiliateLinks", [])
    if not links:
        return ""
    if not isinstance(links, list):
        raise ValueError("affiliateLinks precisa ser uma lista de links reais.")
    items = []
    for item in links:
        if not isinstance(item, dict):
            raise ValueError("Cada recomendação de afiliado precisa ser um objeto.")
        label = str(item.get("name", "")).strip()
        url = str(item.get("url", "")).strip()
        tool_slugs = item.get("toolSlugs", [])
        category_slugs = item.get("categorySlugs", [])
        parsed = urlparse(url)
        if not label or parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
            raise ValueError("Cada link de afiliado precisa de nome e URL HTTPS válida, sem credenciais.")
        if not isinstance(tool_slugs, list) or not isinstance(category_slugs, list) or not (tool_slugs or category_slugs):
            raise ValueError("Cada link de afiliado precisa de pelo menos um escopo em toolSlugs ou categorySlugs.")
        if valid_tool_slugs is not None and not set(tool_slugs).issubset(valid_tool_slugs):
            raise ValueError("toolSlugs contém uma calculadora inexistente.")
        if valid_category_slugs is not None and not set(category_slugs).issubset(valid_category_slugs):
            raise ValueError("categorySlugs contém uma categoria inexistente.")
        if tool_slug not in tool_slugs and category_slug not in category_slugs:
            continue
        items.append(f'<li><a href="{esc(url)}" target="_blank" rel="sponsored nofollow noopener noreferrer">{esc(label)}</a></li>')
    if not items:
        return ""
    return '<section class="affiliate-section" aria-label="Recomendações comerciais"><h2>Recomendações comerciais</h2><p>Alguns links desta seção podem gerar comissão para o CalculaFácil, sem custo adicional para você.</p><ul>' + "".join(items) + "</ul></section>"


def render_breadcrumbs(items: list[tuple[str, str]], origin: str, base_path: str) -> str:
    rendered = ['<nav class="breadcrumbs" aria-label="Trilha de navegação"><ol>']
    for index, (label, route) in enumerate(items):
        if index == len(items) - 1:
            rendered.append(f'<li aria-current="page">{esc(label)}</li>')
        else:
            link_target = "./" if route == "/" else route.lstrip("/")
            rendered.append(f'<li><a href="{esc(link_target)}">{esc(label)}</a></li>')
    rendered.append("</ol></nav>")
    return "".join(rendered)


def render_breadcrumb_json(items: list[tuple[str, str]], origin: str, base_path: str) -> dict | None:
    if not origin:
        return None
    entries = []
    for index, (label, route) in enumerate(items, start=1):
        entry = {"@type": "ListItem", "position": index, "name": label}
        entry["item"] = canonical_for(origin, base_path, route)
        entries.append(entry)
    return {"@type": "BreadcrumbList", "itemListElement": entries}


def page_schema(title: str, description: str, route: str, origin: str, base_path: str,
                breadcrumbs: list[tuple[str, str]], page_type: str = "WebPage", tool: dict | None = None) -> dict:
    graph: list[dict] = []
    canonical = canonical_for(origin, base_path, route)
    page_entity: dict = {"@type": page_type, "name": title, "description": description, "inLanguage": "pt-BR"}
    if canonical:
        page_entity["url"] = canonical
        page_entity["@id"] = canonical + "#pagina"
        page_entity["isPartOf"] = {"@id": canonical_for(origin, base_path, "/") + "#site"}
    graph.append(page_entity)
    breadcrumb = render_breadcrumb_json(breadcrumbs, origin, base_path)
    if breadcrumb:
        graph.append(breadcrumb)
    if tool:
        app: dict = {
            "@type": "WebApplication",
            "name": tool["name"],
            "description": tool["seoDescription"],
            "applicationCategory": "UtilitiesApplication",
            "operatingSystem": "Any",
            "browserRequirements": "Requires JavaScript; runs in a modern web browser.",
            "offers": {"@type": "Offer", "price": "0", "priceCurrency": "BRL"}
        }
        if canonical:
            app["url"] = canonical
        graph.append(app)
        faqs = tool.get("faqs", [])
        if faqs:
            graph.append({
                "@type": "FAQPage",
                "mainEntity": [
                    {"@type": "Question", "name": faq["question"],
                     "acceptedAnswer": {"@type": "Answer", "text": faq["answer"]}}
                    for faq in faqs
                ]
            })
    if route == "/" and origin:
        graph.append({"@type": "WebSite", "@id": canonical_for(origin, base_path, "/") + "#site", "url": canonical_for(origin, base_path, "/"), "name": "CalculaFácil", "inLanguage": "pt-BR"})
    return {"@context": "https://schema.org", "@graph": graph}


def build_page(layout: str, *, title: str, description: str, keywords: list[str], content: str,
               route: str, origin: str, base_path: str, site_config: dict,
               jsonld: dict, robots: str = "index,follow") -> str:
    canonical = canonical_for(origin, base_path, route)
    canonical_tag = f'<link rel="canonical" href="{esc(canonical)}">' if canonical else ""
    og_url = f'<meta property="og:url" content="{esc(canonical)}">' if canonical else ""
    if not origin:
        robots = "noindex,nofollow"
    skip_route = "./" if route == "/" else route.lstrip("/")
    skip_target = esc(f"{skip_route}#main-content")
    twitter_image = ""
    og_image = ""
    if origin:
        image = canonical_for(origin, base_path, "/assets/social-card.png")
        og_image = f'<meta property="og:image" content="{esc(image)}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="CalculaFácil — ferramentas gratuitas para facilitar sua vida">'
        twitter_image = f'<meta name="twitter:image" content="{esc(image)}">'
    elif os.environ.get("CALCAFACIL_PREVIEW") == "1":
        image = "/manus-storage/async-images/G5mRseRHqjqjzOn54TeZY9/image-1.webp"
        og_image = f'<meta property="og:image" content="{image}"><meta property="og:image:type" content="image/webp"><meta property="og:image:alt" content="Ilustração azul e verde de uma calculadora">'
        twitter_image = f'<meta name="twitter:image" content="{image}">'
    verification = ""
    token = str(site_config.get("googleSiteVerification", "")).strip()
    if token:
        verification = f'<meta name="google-site-verification" content="{esc(token)}">'
    result = layout
    replacements = {
        "__BASE_HREF__": esc(f"{base_path}/" if base_path else "/"),
        "__SKIP_LINK__": skip_target,
        "__TITLE__": esc(title),
        "__DESCRIPTION__": esc(description),
        "__KEYWORDS__": esc(", ".join(keywords[:8])),
        "__ROBOTS__": esc(robots),
        "__CANONICAL__": canonical_tag,
        "__OG_URL__": og_url,
        "__OG_IMAGE__": og_image,
        "__TWITTER_IMAGE__": twitter_image,
        "__VERIFICATION__": verification,
        "__JSON_LD__": jsonld_script(jsonld),
        "__SITE_CONFIG__": safe_json(site_config),
        "__CONTENT__": content
    }
    for marker, value in replacements.items():
        result = result.replace(marker, value)
    return result


def render_field(field: dict) -> str:
    name = esc(field["name"])
    label = esc(field["label"])
    field_id = f"field-{name}"
    hint = field.get("help")
    hint_html = f'<p class="field-hint" id="{field_id}-hint">{esc(hint)}</p>' if hint else ""
    described_by = f' aria-describedby="{field_id}-hint"' if hint else ""
    required = "" if field.get("optional") else " required"
    unit = str(field.get("unit", ""))
    suffix = f'<span class="field-suffix" aria-hidden="true">{esc(unit)}</span>' if unit else ""
    if field["type"] == "select":
        options = ['<option value="">Selecione</option>']
        if field.get("dynamicUnits"):
            options = ['<option value="">Selecione uma unidade</option>']
        else:
            for option in field.get("options", []):
                options.append(f'<option value="{esc(option["value"])}">{esc(option["label"])}</option>')
        control = f'<select id="{field_id}" name="{name}"{required}{described_by}>{"".join(options)}</select>'
    else:
        min_attr = f' min="{esc(field["min"])}"' if field.get("min") is not None else ""
        max_attr = f' max="{esc(field["max"])}"' if field.get("max") is not None else ""
        step_value = field.get("step", "any")
        step_attr = f' step="{esc(step_value)}"'
        control = f'<input class="{"has-suffix" if unit else ""}" id="{field_id}" name="{name}" type="number" inputmode="decimal" autocomplete="off"{min_attr}{max_attr}{step_attr}{required}{described_by}>'
    return f'<div class="field"><label for="{field_id}">{label}</label><div class="input-wrap">{control}{suffix}</div>{hint_html}</div>'


def render_tool_page(tool: dict, tools_by_slug: dict[str, dict], category_names: dict[str, str], layout: str,
                     origin: str, base_path: str, site_config: dict) -> str:
    category_name = category_names[tool["category"]]
    route = f'/ferramentas/{tool["slug"]}/'
    crumbs = [("Início", "/"), (category_name, f'/categoria/{tool["category"]}/'), (tool["name"], route)]
    breadcrumb_html = render_breadcrumbs(crumbs, origin, base_path)
    fields_html = "".join(render_field(field) for field in tool["fields"])
    field_list = "".join(f"<li><strong>{esc(field['label'])}:</strong> {esc(field.get('help', 'informe o valor que deseja usar.'))}</li>" for field in tool["fields"])
    related_tools = [tools_by_slug[slug] for slug in tool.get("related", []) if slug in tools_by_slug]
    related_html = "".join(render_tool_card(item, category_names) for item in related_tools)
    how_to_use_html = "".join(f"<li>{esc(step)}</li>" for step in tool.get("howToUse", []))
    use_cases_html = "".join(f"<li>{esc(case)}</li>" for case in tool.get("useCases", []))
    faq_html = "".join(f'<details class="faq"><summary>{esc(faq["question"])}</summary><p>{esc(faq["answer"])}</p></details>' for faq in tool.get("faqs", []))
    source_items = []
    for source in tool.get("researchSources", []):
        source_url = str(source.get("url", "")).strip()
        parsed_source = urlparse(source_url)
        if parsed_source.scheme == "https" and parsed_source.netloc:
            source_items.append(f'<li><a href="{esc(source_url)}" target="_blank" rel="noopener noreferrer">{esc(source.get("title", "Fonte consultada"))}</a><span>{esc(source.get("relevance", ""))}</span></li>')
    sources_html = f'<section class="content-card source-card"><h2>Fontes consultadas</h2><ul class="sources-list">{"".join(source_items)}</ul></section>' if source_items else ""
    affiliate_html = render_affiliate_links(site_config, tool_slug=tool["slug"], category_slug=tool["category"],
                                            valid_tool_slugs=set(tools_by_slug), valid_category_slugs=set(category_names))
    category_label = esc(category_name)
    content = f'''<div class="page-width">
  {breadcrumb_html}
  <header class="page-intro">
    <p class="eyebrow">{category_label}</p>
    <h1>{esc(tool["name"])}</h1>
    <p>{esc(tool["intro"])}</p>
  </header>
  <section class="calculator-layout" aria-label="Calculadora e resultado">
    <div class="panel calculator-panel">
      <h2>Informe seus dados</h2>
      <p class="panel-lead">Os campos não têm valores pré-preenchidos. Use os dados que deseja comparar.</p>
      <form data-calculator-form data-calculator-type="{esc(tool["type"])}" novalidate>
        <div class="field-grid">{fields_html}</div>
        <button class="calculate-button" type="submit">Calcular agora</button>
      </form>
    </div>
    <section class="panel result-panel" data-result-panel aria-labelledby="result-heading" aria-live="polite" aria-atomic="true">
      <div class="result-top"><p class="result-label" id="result-heading">Resultado</p><p class="result-summary" data-result-summary>Seu resultado aparece aqui</p></div>
      <div class="result-body"><p class="result-error" data-result-error role="alert" hidden></p><dl class="result-metrics" data-result-metrics></dl><p class="result-explanation" data-result-explanation>Preencha os campos para ver o resultado. Seus dados são calculados neste navegador.</p></div>
    </section>
  </section>
  {render_ad_slot(site_config, "calculator")}
  <section class="content-card">
    <h2>Como usar esta calculadora</h2>
    <ol>{how_to_use_html}</ol>
    <h3>Fórmula usada</h3>
    <p>{esc(tool["formula"])}</p>
    <h3>Exemplo prático</h3>
    <p>{esc(tool["workedExample"])}</p>
    <h3>Quando usar</h3>
    <ul>{use_cases_html}</ul>
    <h3>Limites e premissas</h3>
    <p>{esc(tool["tip"])}</p>
  </section>
  {sources_html}
  <section class="content-card">
    <h2>Perguntas frequentes</h2>
    <div class="faq-list">{faq_html}</div>
  </section>
  <section class="related-section"><h2>Ferramentas relacionadas</h2><div class="tools-grid">{related_html}</div></section>
  {affiliate_html}
</div>'''
    schema = page_schema(tool["seoTitle"], tool["seoDescription"], route, origin, base_path, crumbs, tool=tool)
    return build_page(layout, title=tool["seoTitle"], description=tool["seoDescription"], keywords=tool["keywords"], content=content,
                      route=route, origin=origin, base_path=base_path, site_config=site_config, jsonld=schema)


def render_home(tools: list[dict], categories: list[dict], pages: dict, category_names: dict[str, str], layout: str,
                origin: str, base_path: str, site_config: dict) -> str:
    popular = [tool for tool in tools if tool.get("popular")]
    category_cards = "".join(render_category_card(category, sum(1 for tool in tools if tool["category"] == category["slug"])) for category in categories)
    popular_cards = "".join(render_tool_card(tool, category_names) for tool in popular)
    all_cards = "".join(render_tool_card(tool, category_names) for tool in tools)
    home_keywords = ["calculadoras online", "ferramentas gratuitas", "calculadora de consumo de energia",
                     "comparador de preços", "calculadora de tinta por m²", "calculadora de papel de parede",
                     "calculadora de média ponderada", "calculadora de viagem"]
    content = f'''<section class="home-hero"><div class="page-width hero-content">
  <p class="hero-kicker">Ferramentas gratuitas para facilitar sua vida</p>
  <h1>Resolva as contas do dia a dia com mais clareza.</h1>
  <p>Calculadoras simples, resultados instantâneos e explicações diretas. Você informa os valores; o cálculo acontece no seu navegador.</p>
  <form class="hero-search" action="./" method="get" role="search" data-search-form>
    <label class="visually-hidden" for="hero-search-input">Pesquisar entre as ferramentas</label>
    <input id="hero-search-input" name="q" type="search" placeholder="Ex.: consumo de energia, desconto, viagem" data-site-search>
    <button type="submit">Buscar ferramenta</button>
  </form>
</div></section>
<div class="page-width">
  <section class="content-section" aria-labelledby="categories-heading">
    <div class="section-heading"><div><p class="eyebrow">Encontre por assunto</p><h2 id="categories-heading">Categorias de ferramentas</h2><p>Escolha um tema para ver as calculadoras relacionadas.</p></div></div>
    <div class="category-list">{category_cards}</div>
  </section>
  <section class="content-section" aria-labelledby="popular-heading">
    <div class="section-heading"><div><p class="eyebrow">Para começar</p><h2 id="popular-heading">Ferramentas populares</h2><p>Atalhos para cálculos usados com frequência.</p></div></div>
    <div class="tools-grid">{popular_cards}</div>
  </section>
  {render_ad_slot(site_config, "homepage")}
  <section class="content-section" id="all-tools" aria-labelledby="all-tools-heading">
    <div class="section-heading"><div><p class="eyebrow">Catálogo completo</p><h2 id="all-tools-heading">Todas as ferramentas</h2><p>Pesquise ou abra uma calculadora para ver instruções e fórmulas.</p></div></div>
    <div class="tools-grid">{all_cards}</div>
    {render_search_empty()}
  </section>
</div>'''
    route = "/"
    schema = page_schema("CalculaFácil | Ferramentas gratuitas", pages["siteDescription"], route, origin, base_path, [("Início", "/")], page_type="WebPage")
    return build_page(layout, title="CalculaFácil | Ferramentas gratuitas", description=pages["siteDescription"],
                      keywords=home_keywords,
                      content=content, route=route, origin=origin, base_path=base_path, site_config=site_config, jsonld=schema)


def render_category(category: dict, tools: list[dict], category_names: dict[str, str], layout: str,
                    origin: str, base_path: str, site_config: dict) -> str:
    route = f'/categoria/{category["slug"]}/'
    category_tools = [tool for tool in tools if tool["category"] == category["slug"]]
    crumbs = [("Início", "/"), (category["name"], route)]
    breadcrumb_html = render_breadcrumbs(crumbs, origin, base_path)
    cards = "".join(render_tool_card(tool, category_names) for tool in category_tools)
    affiliate_html = render_affiliate_links(site_config, category_slug=category["slug"],
                                            valid_tool_slugs={tool["slug"] for tool in tools},
                                            valid_category_slugs=set(category_names))
    content = f'''<div class="page-width">{breadcrumb_html}
  <header class="category-hero"><span class="category-icon">{category_icon(category["icon"])}</span><div><p class="eyebrow">Categoria</p><h1>{esc(category["name"])}</h1><p>{esc(category["description"])}</p></div></header>
  <section class="content-section" aria-labelledby="category-tools-heading"><div class="section-heading"><div><h2 id="category-tools-heading">Ferramentas de {esc(category["name"].lower())}</h2><p>Abra uma ferramenta para informar seus valores e consultar a fórmula.</p></div></div><div class="tools-grid">{cards}</div>{render_search_empty()}</section>
  {affiliate_html}
</div>'''
    seo_title = category.get("seoTitle", f'{category["name"]} | Calculadoras gratuitas CalculaFácil')
    seo_description = category.get("seoDescription", category["description"])
    keywords = category.get("keywords", [category["name"].lower(), "calculadoras gratuitas", "ferramentas online", "cálculos do dia a dia"])
    schema = page_schema(seo_title, seo_description, route, origin, base_path, crumbs, page_type="CollectionPage")
    return build_page(layout, title=seo_title, description=seo_description, keywords=keywords, content=content,
                      route=route, origin=origin, base_path=base_path, site_config=site_config, jsonld=schema)


def render_information_page(key: str, page: dict, layout: str, origin: str, base_path: str, site_config: dict) -> str:
    route = f'/{key}/'
    crumbs = [("Início", "/"), (page["title"], route)]
    breadcrumb_html = render_breadcrumbs(crumbs, origin, base_path)
    section_html = []
    for section in page.get("sections", []):
        paragraphs = "".join(f"<p>{esc(paragraph)}</p>" for paragraph in section.get("paragraphs", []))
        links = "".join(f'<p class="source-link"><a href="{esc(link["url"])}" target="_blank" rel="noopener noreferrer">{esc(link["label"])}</a></p>' for link in section.get("links", []) if urlparse(link.get("url", "")).scheme == "https")
        section_html.append(f'<section class="content-card"><h2>{esc(section["heading"])}</h2>{paragraphs}{links}</section>')
    if key == "contato":
        contact = '<div class="notice" data-contact-email><strong>Endereço ainda não configurado.</strong><br>O responsável poderá informar um e-mail real em <code>src/data/site.config.json</code> antes de publicar. Este site não coleta mensagens.</div>'
        section_html.append(contact)
    if key == "anuncie-no-calculafacil":
        contact = '<section class="content-card"><h2>Contato comercial</h2><p>O canal só aparece quando o responsável configura um endereço verdadeiro; esta página não coleta mensagens.</p><div class="notice" data-contact-email><strong>Endereço comercial ainda não configurado.</strong><br>Não há formulário nem contato presumido nesta versão.</div><p><a href="contato/">Ver informações gerais de contato</a></p></section>'
        section_html.append(contact)
    content = f'''<div class="page-width">{breadcrumb_html}<header class="page-intro"><p class="eyebrow">CalculaFácil</p><h1>{esc(page["title"])}</h1><p>{esc(page["intro"])}</p></header>{"".join(section_html)}</div>'''
    page_type = {"sobre": "AboutPage", "contato": "ContactPage", "privacidade": "WebPage", "termos": "WebPage"}.get(key, "WebPage")
    schema = page_schema(page["seoTitle"], page["seoDescription"], route, origin, base_path, crumbs, page_type=page_type)
    keywords = page.get("keywords", [page["title"].lower(), "CalculaFácil", "ferramentas gratuitas"])
    return build_page(layout, title=page["seoTitle"], description=page["seoDescription"], keywords=keywords,
                      content=content, route=route, origin=origin, base_path=base_path, site_config=site_config, jsonld=schema)


def validate_source(tools: list[dict], categories: list[dict], pages: dict) -> None:
    if len(tools) != 18:
        raise ValueError(f"O projeto precisa conter exatamente 18 ferramentas; foram encontradas {len(tools)}.")
    slugs = [tool["slug"] for tool in tools]
    if len(slugs) != len(set(slugs)):
        raise ValueError("Há slugs de ferramenta duplicados.")
    category_slugs = {category["slug"] for category in categories}
    if len(category_slugs) != len(categories):
        raise ValueError("Há slugs de categoria duplicados.")
    for tool in tools:
        if tool["category"] not in category_slugs:
            raise ValueError(f'Categoria ausente para {tool["slug"]}.')
        for related in tool.get("related", []):
            if related not in slugs:
                raise ValueError(f'Referência relacionada ausente: {related}.')
    if len(categories) != 7:
        raise ValueError(f"O projeto espera sete categorias; foram encontradas {len(categories)}.")
    for page in ("sobre", "contato", "privacidade", "termos", "anuncie-no-calculafacil"):
        if page not in pages.get("pages", {}):
            raise ValueError(f"Página informativa ausente: {page}.")
    for tool in tools:
        if len(tool.get("faqs", [])) < 4:
            raise ValueError(f'Cada ferramenta precisa ter pelo menos quatro FAQs específicas: {tool["slug"]}.')
        if not tool.get("primaryKeyword") or not tool.get("researchSources"):
            raise ValueError(f'Palavra-chave e fontes precisam estar documentadas: {tool["slug"]}.')


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def build_site(output: Path, origin: str, base_path: str) -> dict:
    tools = read_json(DATA / "tools.json")
    categories = read_json(DATA / "categories.json")
    pages = read_json(DATA / "pages.json")
    site_config = read_json(DATA / "site.config.json")
    validate_source(tools, categories, pages)
    origin = normalize_origin(origin)
    base_path = normalize_base_path(base_path)
    if output.exists():
        if output.resolve() == ROOT.resolve() or not output.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError("A pasta de saída precisa ser uma pasta dentro do projeto, diferente da raiz.")
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    layout = (TEMPLATES / "layout.html").read_text(encoding="utf-8")
    category_names = {category["slug"]: category["name"] for category in categories}
    routes: list[dict[str, str]] = [{"path": "/", "title": "CalculaFácil | Ferramentas gratuitas"}]
    routes.extend({"path": f'/ferramentas/{tool["slug"]}/', "title": tool["seoTitle"]} for tool in tools)
    routes.extend({"path": f'/categoria/{category["slug"]}/', "title": category.get("seoTitle", f'{category["name"]} | Calculadoras gratuitas CalculaFácil')} for category in categories)
    routes.extend({"path": f'/{key}/', "title": page["seoTitle"]} for key, page in pages["pages"].items())

    home = render_home(tools, categories, pages, category_names, layout, origin, base_path, site_config)
    write_text(output / "index.html", home)
    tools_by_slug = {tool["slug"]: tool for tool in tools}
    for tool in tools:
        page = render_tool_page(tool, tools_by_slug, category_names, layout, origin, base_path, site_config)
        write_text(output / "ferramentas" / tool["slug"] / "index.html", page)
    for category in categories:
        page = render_category(category, tools, category_names, layout, origin, base_path, site_config)
        write_text(output / "categoria" / category["slug"] / "index.html", page)
    for key, page_data in pages["pages"].items():
        page = render_information_page(key, page_data, layout, origin, base_path, site_config)
        write_text(output / key / "index.html", page)

    asset_output = output / "assets"
    asset_output.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SRC / "css" / "styles.css", asset_output / "styles.css")
    shutil.copy2(SRC / "css" / "accessibility.css", asset_output / "accessibility.css")
    shutil.copy2(SRC / "js" / "app.mjs", asset_output / "app.mjs")
    shutil.copy2(SRC / "js" / "calculators.mjs", asset_output / "calculators.mjs")
    for filename in ("logo.svg", "favicon.svg", "social-card.svg", "social-card.png", "icon-192.png", "icon-512.png"):
        shutil.copy2(ASSETS / filename, asset_output / filename)

    # Static metadata is generated from actual public URLs only after an origin is configured.
    manifest = {
        "name": "CalculaFácil — Ferramentas Gratuitas para o Dia a Dia",
        "short_name": "CalculaFácil",
        "description": pages["siteDescription"],
        "lang": "pt-BR",
        "start_url": f"{base_path}/" if base_path else "/",
        "scope": f"{base_path}/" if base_path else "/",
        "display": "standalone",
        "background_color": "#F4F6F8",
        "theme_color": "#103B63",
        "icons": [
            {"src": "assets/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
            {"src": "assets/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}
        ]
    }
    write_text(output / "manifest.webmanifest", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")

    route_list = [item["path"] for item in routes]
    cache_digest = hashlib.sha256()
    for path in sorted(item for item in output.rglob("*") if item.is_file()):
        cache_digest.update(str(path.relative_to(output)).encode("utf-8"))
        cache_digest.update(path.read_bytes())
    cache_version = cache_digest.hexdigest()[:12]
    precache = ["./", "./manifest.webmanifest", "./assets/styles.css", "./assets/accessibility.css", "./assets/app.mjs", "./assets/calculators.mjs", "./assets/logo.svg", "./assets/favicon.svg", "./assets/icon-192.png", "./assets/icon-512.png"]
    precache.extend("." + route if route != "/" else "./" for route in route_list[1:])
    worker = f'''const CACHE_NAME = "calculafacil-{cache_version}";
const PRECACHE_URLS = {json.dumps(precache, ensure_ascii=False)};
self.addEventListener("install", (event) => {{
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS)).then(() => self.skipWaiting()));
}});
self.addEventListener("activate", (event) => {{
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith("calculafacil-") && key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
}});
self.addEventListener("fetch", (event) => {{
  if (event.request.method !== "GET" || new URL(event.request.url).origin !== self.location.origin) return;
  if (event.request.mode === "navigate") {{
    event.respondWith(fetch(event.request).then((response) => {{
      if (response.ok) {{ const copy = response.clone(); caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)); }}
      return response;
    }}).catch(async () => (await caches.match(event.request, {{ ignoreSearch: true }})) || caches.match("./")));
    return;
  }}
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {{
    if (response.ok) {{ const copy = response.clone(); caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)); }}
    return response;
  }})));
}});
'''
    write_text(output / "sw.js", worker)
    write_text(output / "manus-routes.json", json.dumps({"routes": routes}, ensure_ascii=False, indent=2) + "\n")

    if origin:
        robots = "User-agent: *\nAllow: /\n"
        robots += f"Sitemap: {canonical_for(origin, base_path, '/sitemap.xml')}\n"
        sitemap_urls = "".join(f"  <url><loc>{xml_escape(canonical_for(origin, base_path, route))}</loc></url>\n" for route in route_list)
        sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + sitemap_urls + "</urlset>\n"
        write_text(output / "sitemap.xml", sitemap)
    else:
        robots = "User-agent: *\nDisallow: /\n"
        sitemap = ""
    write_text(output / "robots.txt", robots)

    not_found_content = '''<div class="page-width"><header class="page-intro"><p class="eyebrow">Página não encontrada</p><h1>Não encontramos este endereço.</h1><p>Confira o link ou volte para a página inicial para escolher uma ferramenta.</p><p><a href="./">Ir para o início</a></p></header></div>'''
    not_found_schema = page_schema("Página não encontrada | CalculaFácil", "Este endereço não corresponde a uma página do CalculaFácil.", "/404.html", "", base_path, [])
    not_found = build_page(layout, title="Página não encontrada | CalculaFácil", description="Este endereço não corresponde a uma página do CalculaFácil.",
                           keywords=["CalculaFácil", "página não encontrada", "ferramentas gratuitas"], content=not_found_content,
                           route="/404.html", origin="", base_path=base_path, site_config=site_config, jsonld=not_found_schema, robots="noindex,follow")
    write_text(output / "404.html", not_found)

    return {"pages": len(routes), "tools": len(tools), "categories": len(categories), "origin": origin, "base_path": base_path, "sitemap_generated": bool(sitemap), "output": str(output)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Gera o site estático CalculaFácil.")
    parser.add_argument("--output", default=str(ROOT / "dist"), help="Pasta de saída dentro do projeto (padrão: dist).")
    parser.add_argument("--site-origin", default=os.environ.get("SITE_ORIGIN", ""), help="Origem HTTPS pública real, sem caminho.")
    parser.add_argument("--base-path", default=os.environ.get("SITE_BASE_PATH", ""), help="Caminho real do site, como /calculafacil; deixe vazio na raiz.")
    args = parser.parse_args()
    try:
        output = Path(args.output)
        if not output.is_absolute():
            output = ROOT / output
        summary = build_site(output, args.site_origin, args.base_path)
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print(f"Erro ao gerar o site: {error}", file=sys.stderr)
        return 1
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not summary["sitemap_generated"]:
        print("Nota: sitemap.xml e URLs canônicas só são gerados quando a origem HTTPS real é configurada.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
