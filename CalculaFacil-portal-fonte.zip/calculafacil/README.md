# CalculaFácil

**Site publicado:** [CalculaFácil](https://pedroicsan.github.io/calculafacil/)
**Repositório público:** [pedroicsan/calculafacil](https://github.com/pedroicsan/calculafacil)

Portal estático em português brasileiro com **18 calculadoras**, distribuídas em **7 categorias**, mais páginas informativas — 31 rotas públicas pré-geradas no total. A coleção mantém as 15 ferramentas originais e acrescenta calculadoras de quantidade de tinta, rolos de papel de parede e média ponderada. As contas são feitas no navegador e não dependem de banco de dados, login, modelo de IA, API ou pacote npm.

## Construir e executar localmente

Para desenvolvimento, use Python 3 e Node.js 20 ou superior. A versão publicada é HTML, CSS, JavaScript e SVG/PNG estáticos; Node é necessário apenas para os testes.

```sh
python3 scripts/build_site.py
node --test tests/calculators.test.mjs
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 -m http.server 3000 --directory dist
```

Depois abra `http://localhost:3000/`. O gerador cria a pasta `dist/` com páginas, recursos, manifesto PWA, service worker, `robots.txt` e o manifesto de rotas. `sitemap.xml` e URLs canônicas são acrescentados quando você fornece a origem HTTPS pública real. Para interromper o servidor, use `Ctrl+C`.

## Hospedagem gratuita no GitHub Pages

O arquivo `.github/workflows/pages.yml` constrói e publica o site estático por GitHub Actions. No GitHub Free, a documentação oficial exige que o repositório que hospeda o Pages seja **público**. Isso torna o código-fonte também visível; não publique senhas, dados privados ou identificadores que não sejam destinados a um site público. A própria página publicada é pública. GitHub informa que registra IPs de visitantes para segurança. Leia [as notas oficiais e os links consultados](docs/free-hosting.md) antes de escolher essa opção.

Para publicar, crie uma conta gratuita no GitHub, crie um repositório público vazio chamado `calculafacil` e extraia o ZIP-fonte em um computador. No terminal, dentro da pasta extraída, envie os arquivos para a branch `main` (substitua `SEU-USUARIO` pelo nome real da conta):

```sh
git init -b main
git add .
git commit -m "Publica CalculaFácil"
git remote add origin https://github.com/SEU-USUARIO/calculafacil.git
git push -u origin main
```

Depois, no repositório, em **Settings → Pages → Build and deployment → Source**, selecione **GitHub Actions**. O fluxo incluído usa os caminhos padrão de site de projeto ou de usuário e publica em cada atualização da branch `main`. Como o repositório deve ser público no GitHub Free, o código e o conteúdo do portal ficarão visíveis para qualquer pessoa; confirme que não há dados privados antes do envio. A primeira publicação depende da conta, do repositório público e da ativação do Pages; não é necessário comprar domínio nem contratar outro host.

Para domínio próprio, primeiro configure-o nas opções do GitHub Pages e no provedor DNS. Isso requer adquirir o domínio (não incluído e não necessário para usar o endereço `github.io`). A documentação do GitHub recomenda `CNAME` para subdomínio e registros `A`, `ALIAS` ou `ANAME` para domínio raiz. Se usar domínio próprio, configure as variáveis de repositório `SITE_ORIGIN` (por exemplo, `https://www.seudominio.com`) e, se necessário, `SITE_BASE_PATH` em **Settings → Secrets and variables → Actions → Variables**. Para o domínio padrão do GitHub, deixe as variáveis vazias; o fluxo deriva a origem e o caminho do repositório. O sitemap só será criado com uma origem pública HTTPS real.

Para outra hospedagem estática, gere o site com a origem real e o caminho-base daquele provedor:

```sh
python3 scripts/build_site.py --site-origin https://SEU-ENDERECO-REAL --base-path /CAMINHO-DO-SITE
```

Deixe `--base-path` vazio se o site estiver na raiz do domínio. `SEU-ENDERECO-REAL` é uma instrução de configuração, não uma URL publicada. Não envie ao Google um sitemap de demonstração.

## Search Console, Analytics e monetização

A propriedade de prefixo `https://pedroicsan.github.io/calculafacil/` foi verificada no Search Console por arquivo HTML. O arquivo oficial gerado pelo Google fica em `src/root-files/`; `googleSiteVerification` permanece vazio porque a verificação não usa meta tag. O sitemap está publicado e foi enviado ao Search Console, mas o painel ainda não confirmou que concluiu a leitura. A publicação do sitemap não garante indexação.

O fluxo Web do GA4 para o CalculaFácil está configurado com o ID público `G-47YHEZD21Z`. `googleAnalyticsEnabled` está ativado, mas a tag só é carregada depois que a pessoa aceita Analytics; a recusa não a carrega e a escolha pode ser alterada no rodapé. A medição otimizada e os sinais de publicidade estão desativados. A URL enviada ao Analytics não contém consulta ou fragmento e os valores das calculadoras não são coletados. Consulte a Política de Privacidade e [o estado detalhado das integrações](docs/monetizacao-e-analitica.md).

Edite `src/data/site.config.json` somente com valores legítimos, destinados a aparecer no site público. `contactEmail` define o e-mail exibido na página Contato. O ID GA4 pode ser substituído se o site for transferido para uma propriedade sob controle de outro responsável; não é uma credencial secreta.

O AdSense continua desativado. Só depois da aprovação, informe o identificador oficial em `adsenseClientId`, os IDs legítimos em `adsSlots.homepage` e `adsSlots.calculator`, e então habilite `adsEnabled`. Nessa configuração, os espaços correspondentes carregam o script oficial. Atualize a Política de Privacidade antes de ativar publicidade. Os cálculos continuam funcionais sem anúncios.

`affiliateLinks` permanece vazio. Adicione somente URLs e rótulos reais, autorizados pelo programa escolhido; o portal os exibirá com identificação de link comercial. Nenhuma aprovação, parceria, URL ou comissão é presumida.

## Arquitetura

- `src/data/`: dados das ferramentas, categorias, páginas e opções públicas do site.
- `src/js/calculators.mjs`: fórmulas puras, separadas da interface.
- `src/js/app.mjs`: atualização instantânea, pesquisa, integrações opcionais e registro offline.
- `src/css/`: estilos responsivos e utilitários de acessibilidade.
- `src/templates/`: estrutura HTML comum.
- `scripts/build_site.py`: gera HTML e arquivos de SEO sem dependências externas.
- `tests/`: testes matemáticos com `node --test` e testes de saída/SEO com `python3 -m unittest`.
- `.github/workflows/pages.yml`: publicação gratuita opcional em GitHub Pages.
- `docs/free-hosting.md`: resumo e fontes oficiais sobre Pages, privacidade e domínio.
- `docs/fase-2/`: auditoria individual de SEO, pesquisa qualitativa e fontes por calculadora.
- `docs/relatorio-fase-2.md`: relatório final com resultados, palavras-chave, limites e passos do proprietário.
- `docs/monetizacao-e-analitica.md`: configuração real de GA4 e Search Console, consentimento e pendências externas.

O service worker pode abrir páginas já carregadas depois que a pessoa visita o site online pela primeira vez; a primeira visita requer conexão. O site não guarda os valores digitados nos campos. A versão inicial não requer manutenção diária, serviços pagos, servidor Manus, créditos de IA ou API para executar os cálculos.
