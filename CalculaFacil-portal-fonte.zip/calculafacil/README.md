# CalculaFácil

Portal estático de calculadoras em português brasileiro. As contas são feitas no navegador e não dependem de banco de dados, login, modelo de IA, API ou pacote npm.

## Construir e executar localmente

Para desenvolvimento, use Python 3 e Node.js 20 ou superior. A versão publicada é HTML, CSS, JavaScript e SVG/PNG estáticos; Node é necessário apenas para os testes.

```sh
python3 scripts/build_site.py
node --test tests/calculators.test.mjs
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 -m http.server 3000 --directory dist
```

Depois abra `http://localhost:3000/`. O gerador cria a pasta `dist/` com páginas, recursos, manifesto PWA, service worker, `robots.txt` e o manifesto de rotas. `sitemap.xml` e URLs canônicas são acrescentados quando você fornece a origem HTTPS pública real. Para interromper o servidor, use `Ctrl+C`.

## Hospedagem gratuita no GitHub Pages

O arquivo `.github/workflows/pages.yml` constrói e publica o site estático por GitHub Actions. No GitHub Free, a documentação oficial exige que o repositório que hospeda o Pages seja **público**. Isso torna o código-fonte também visível; não publique senhas, dados privados ou identificadores que não sejam destinados a um site público. A própria página publicada é pública. GitHub informa que registra IPs de visitantes para segurança. Leia [as notas oficiais e os links consultados](docs/free-hosting.md) antes de escolher essa opção.

Para publicar, crie uma conta gratuita no GitHub, crie um repositório público vazio chamado `calculafacil` e extraia o ZIP-fonte em um computador. No terminal, dentro da pasta extraída, envie os arquivos para a branch `main` (substitua `SEU-USUARIO` pelo nome real da conta):

```sh
git init -b main
git add .
git commit -m "Publica CalculaFácil"
git remote add origin https://github.com/SEU-USUARIO/calculafacil.git
git push -u origin main
```

Depois, no repositório, em **Settings → Pages → Build and deployment → Source**, selecione **GitHub Actions**. O fluxo incluído usa os caminhos padrão de site de projeto ou de usuário e publica em cada atualização da branch `main`. Como o repositório deve ser público no GitHub Free, o código e o conteúdo do portal ficarão visíveis para qualquer pessoa; confirme que não há dados privados antes do envio. A primeira publicação depende da conta, do repositório público e da ativação do Pages; não é necessário comprar domínio nem contratar outro host.

Para domínio próprio, primeiro configure-o nas opções do GitHub Pages e no provedor DNS. Isso requer adquirir o domínio (não incluído e não necessário para usar o endereço `github.io`). A documentação do GitHub recomenda `CNAME` para subdomínio e registros `A`, `ALIAS` ou `ANAME` para domínio raiz. Se usar domínio próprio, configure as variáveis de repositório `SITE_ORIGIN` (por exemplo, `https://www.seudominio.com`) e, se necessário, `SITE_BASE_PATH` em **Settings → Secrets and variables → Actions → Variables**. Para o domínio padrão do GitHub, deixe as variáveis vazias; o fluxo deriva a origem e o caminho do repositório. O sitemap só será criado com uma origem pública HTTPS real.

Para outra hospedagem estática, gere o site com a origem real e o caminho-base daquele provedor:

```sh
python3 scripts/build_site.py --site-origin https://SEU-ENDERECO-REAL --base-path /CAMINHO-DO-SITE
```

Deixe `--base-path` vazio se o site estiver na raiz do domínio. `SEU-ENDERECO-REAL` é uma instrução de configuração, não uma URL publicada. Não envie ao Google um sitemap de demonstração.

## Contato, Search Console, Analytics e monetização futura

Edite `src/data/site.config.json` apenas com valores legítimos, destinados a aparecer em um site público. `contactEmail` define o e-mail mostrado na página Contato. `googleSiteVerification` recebe o token oficial de verificação do Google Search Console.

Por padrão, `googleAnalyticsId` está vazio e `googleAnalyticsEnabled` está desativado, portanto nenhum script de analytics é carregado. Se for habilitado com um ID válido, o site apresenta uma escolha explícita; o Google Analytics só será carregado após consentimento afirmativo guardado no navegador. Antes de ativar, atualize a Política de Privacidade e revise os avisos aplicáveis.

AdSense também começa desativado. Só depois da aprovação, informe o identificador oficial em `adsenseClientId`, os IDs legítimos em `adsSlots.homepage` e `adsSlots.calculator`, e então habilite `adsEnabled`. Nessa configuração, os espaços correspondentes carregam o script oficial; não há anúncios ativos ou IDs falsos nesta versão. Atualize a Política de Privacidade antes de ativar publicidade. Os cálculos continuam funcionais sem anúncios.

`affiliateLinks` começa como uma lista vazia. Adicione somente URLs e rótulos reais, autorizados pelo programa escolhido; o portal os exibirá com identificação de link comercial. Nenhuma aprovação, parceria, URL ou comissão é presumida.

## Arquitetura

- `src/data/`: dados das ferramentas, categorias, páginas e opções públicas do site.
- `src/js/calculators.mjs`: fórmulas puras, separadas da interface.
- `src/js/app.mjs`: atualização instantânea, pesquisa, integrações opcionais e registro offline.
- `src/css/`: estilos responsivos e utilitários de acessibilidade.
- `src/templates/`: estrutura HTML comum.
- `scripts/build_site.py`: gera HTML e arquivos de SEO sem dependências externas.
- `tests/`: testes matemáticos com `node --test`.
- `.github/workflows/pages.yml`: publicação gratuita opcional em GitHub Pages.
- `docs/free-hosting.md`: resumo e fontes oficiais sobre Pages, privacidade e domínio.

O service worker pode abrir páginas já carregadas depois que a pessoa visita o site online pela primeira vez; a primeira visita requer conexão. O site não guarda os valores digitados nos campos. A versão inicial não requer manutenção diária, serviços pagos, servidor Manus, créditos de IA ou API para executar os cálculos.
