# Fontes oficiais para SEO, Search Console e monetização

**Consultadas em 30/10/2026.** As regras de Google e provedores podem mudar; confirmar sempre a versão atual antes de ativar integrações ou publicidade.

## Search Console e sitemap

- [Google Search Console — verificar a propriedade do site](https://support.google.com/webmasters/answer/9008080?hl=pt-BR). A verificação por meta tag exige inserir o valor exato fornecido pelo Search Console no HTML servido para a propriedade; o Google verifica a presença do token e pode revalidá-lo periodicamente. Para o endereço atual, a orientação prática é selecionar a propriedade de prefixo de URL `https://pedroicsan.github.io/calculafacil/`, copiar o valor exato da meta tag e configurá-lo no campo `googleSiteVerification` do projeto. A propriedade e a verificação ainda dependem do responsável pela conta.
- [Google Search Central — criar e enviar sitemaps](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap). O sitemap XML deve listar URLs absolutas canônicas; um sitemap na raiz é apropriado para o site. Enviar o arquivo pelo relatório Sitemaps do Search Console ou anunciar seu caminho em `robots.txt` pode ajudar o Google a encontrá-lo, mas é apenas uma indicação e não garante rastreamento nem indexação. O sitemap atual é anunciado em `robots.txt`.

## Qualidade editorial

- [Google Search Central — conteúdo útil, confiável e people-first](https://developers.google.com/search/docs/fundamentals/creating-helpful-content). O Google recomenda conteúdo original, útil e correto que satisfaça o leitor; perguntas de autoavaliação incluem oferecer informação original e valor além de reescrever fontes. A própria página diz que não há uma contagem de palavras preferida. A diretriz afasta textos repetitivos feitos principalmente para mecanismos de busca, biografias ou credenciais fabricadas e alegações não verificáveis. Isso orienta exemplos calculados, fórmulas reais, FAQs próprias e fontes sem promessas de ranking.

## AdSense

- [Google AdSense Help — conectar um site e solicitar análise](https://support.google.com/adsense/answer/7584263?hl=pt-BR). O responsável deve adicionar a URL na conta, selecionar um método de verificação/conexão suportado (por exemplo, trecho de código ou meta tag), confirmar e solicitar a análise. O Google informa que não há exibição de anúncios antes da aprovação; a análise pode levar alguns dias e, em alguns casos, de duas a quatro semanas. Este prazo é informativo, não uma garantia de aprovação.
- [Google AdSense Help — políticas do programa](https://support.google.com/adsense/answer/48182?hl=pt-BR) e [Google Publisher Policies](https://support.google.com/adsense/answer/9335564?hl=pt-BR). O editor deve obedecer às políticas e manter-se atualizado. É vedado inflar artificialmente impressões/cliques ou incentivar cliques; posicionamentos não podem ser enganosos nem se confundir com navegação/downloads. O Google pode interromper anúncios ou a participação diante de descumprimento.
- O projeto mantém publicidade desligada, sem IDs, sem anúncios reais e sem aprovação presumida. A integração só pode ser considerada depois de o responsável criar a conta, fornecer IDs legítimos, concluir a aprovação, confirmar as políticas aplicáveis e revisar a política de privacidade. Se ativar, o rótulo visível “Publicidade” e a separação dos controles de cálculo ajudam a evitar confusão, mas não substituem a revisão das regras do Google.

## Links comerciais e afiliados

- [Google Search Central — qualificar links externos](https://developers.google.com/search/docs/crawling-indexing/qualify-outbound-links). O Google recomenda `rel="sponsored"` para anúncios e posicionamentos pagos, incluindo relações comerciais; `nofollow` ainda é aceito para esse propósito. É possível usar múltiplos valores separados por espaço. O projeto já usa `rel="sponsored nofollow noopener noreferrer"` para links comerciais gerados pela estrutura de afiliados; novas exibições contextuais devem preservar essa classificação, a divulgação comercial e a validação de URL HTTPS.

## Limites destas fontes

Essas páginas explicam requisitos e orientações dos respectivos provedores. Não certificam que uma página será indexada, que um site será aceito no AdSense, que um link gerará comissão ou que o portal alcançará determinada posição ou receita. A disponibilidade das integrações permanece condicionada à conta, às permissões, às políticas vigentes e a dados legítimos do proprietário.

## Core Web Vitals

- [Google Search Central — Core Web Vitals e resultados da Pesquisa](https://developers.google.com/search/docs/appearance/core-web-vitals) define LCP, INP e CLS e recomenda, para a faixa “boa”, LCP até 2,5 s, INP abaixo de 200 ms e CLS abaixo de 0,1.
- [Ajuda do Search Console — relatório de Core Web Vitals](https://support.google.com/webmasters/answer/9205520?hl=pt-BR) informa que o relatório usa dados de campo do Chrome UX Report, agrupados por experiência/dispositivo, e pode não mostrar uma propriedade sem volume mínimo de dados reais. Por isso, medições locais/laboratoriais desta auditoria não serão apresentadas como Core Web Vitals de campo nem como aprovação do relatório. Os testes reais de campo dependerão de tráfego suficiente e da conta Search Console do proprietário.
