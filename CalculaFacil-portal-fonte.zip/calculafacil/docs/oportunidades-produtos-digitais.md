# Oportunidades futuras de produtos digitais

Este documento registra hipóteses para validar no futuro. Não há dados de tráfego, busca, receita ou demanda que permitam afirmar que alguma ideia venderá. Não foi criado produto, checkout, pagamento, assinatura ou coleta de dados.

## Ideias que complementam as calculadoras

### Planilha de orçamento mensal da casa

Uma planilha local para registrar renda, despesas fixas e variáveis, dividir contas e acompanhar uma meta de economia. Complementa as ferramentas de economia mensal e divisão de despesas. Para evitar funções financeiras desnecessárias, não conectaria a bancos nem recomendaria investimentos. O visitante preencheria manualmente os valores.

### Controle de custo de energia por aparelho

Uma planilha sem tabelas tarifárias inventadas para registrar potência, horas de uso, dias de uso e a tarifa informada pelo visitante. Poderia comparar cenários de redução de uso e resumir os aparelhos que mais contribuem para o custo calculado. Ela amplia a calculadora de energia quando a pessoa quer organizar vários aparelhos ao longo dos meses.

### Planejador de orçamento de viagem

Um modelo editável para registrar distância, consumo e preço de combustível informados pelo viajante, além de pedágios, hospedagem, alimentação e quantidade de pessoas. Complementa combustível, custo total da viagem e divisão de despesas, sem depender de cotação, mapas ou APIs externas.

### Planilha de comparação de compras

Um arquivo para comparar produtos por quantidade, preço por quilo/litro/unidade e descontos, registrar a data da observação e calcular a diferença entre opções. Complementa comparação de preços e economia entre produtos; não manteria preços de terceiros nem afirmaria que algum produto é o mais barato do mercado.

### Material educativo de matemática financeira cotidiana

Um guia curto com exemplos didáticos construídos a partir das calculadoras de porcentagem, descontos, juros e salário por hora. Deve distinguir exemplos matemáticos de aconselhamento financeiro, declarar premissas e não prometer resultados ou rendimentos.

## Como validar antes de investir tempo

Primeiro, observar consultas e páginas de entrada reais no Search Console depois de configurar a propriedade. As métricas refletem o site e dependem de volume suficiente; não devem ser substituídas por números estimados. Depois, avaliar se consultas e dúvidas reais se alinham à ideia. Uma página informativa pode explicar um eventual recurso, mas não deve anunciar um produto que ainda não existe. Se o responsável já tiver e-mail comercial verdadeiro configurado, pode registrar manifestações de interesse por esse canal, com a divulgação de privacidade adequada.

Só considerar produzir um arquivo quando houver evidência de que o visitante precisa de algo que as calculadoras gratuitas não resolvem — por exemplo, armazenar vários meses de dados ou organizar diversos aparelhos e itens juntos. Manter os cálculos do site completos e gratuitos e não exigir compra para acessar resultado algum.

## Condições para uma etapa futura

Qualquer venda dependeria de o proprietário escolher um formato, criar o arquivo, conferir fórmulas e licenças, avaliar regras tributárias e de privacidade aplicáveis e decidir como entregar o material. Este projeto não fornece aconselhamento jurídico/contábil, não garante receita e não integra serviço de pagamentos. Uma opção leve seria um arquivo offline; não é necessário contratar SaaS para validar se existe interesse.
