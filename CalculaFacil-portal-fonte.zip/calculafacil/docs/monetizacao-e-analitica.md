# Integrações Google e monetização — CalculaFácil

**Atualizado em 30 de outubro de 2026.** O portal continua estático e publicado no GitHub Pages. A configuração do GA4 foi autorizada pelo proprietário; anúncios e afiliados continuam desligados.

## Google Search Console

A propriedade de prefixo `https://pedroicsan.github.io/calculafacil/` foi criada e verificada na conta Google autenticada usando o arquivo de verificação gerado pelo Search Console. O arquivo `google369ea1b000365d6c.html` foi incluído na raiz pública; o arquivo de verificação fornecido pelo proprietário também foi preservado. Ambos fazem parte de `src/root-files/` e são copiados sem alteração durante a geração do site.

O sitemap público é `https://pedroicsan.github.io/calculafacil/sitemap.xml`. A submissão foi iniciada no painel, que atualmente mostra **“Não foi possível buscar o sitemap”**. Em checagens independentes, o sitemap respondeu HTTP 200 como `application/xml` e continha XML válido com 31 URLs; os pedidos com user-agent comum e Googlebot tiveram o mesmo resultado. `robots.txt` e os arquivos de verificação também responderam HTTP 200. A divergência com o painel continua sem diagnóstico confirmado. Por isso, este documento não declara que o Google concluiu a leitura ou indexou as páginas. Acompanhe o painel após novo recrawl e, se o erro persistir, confira o diagnóstico do Google e reenvie a URL completa na propriedade correta.

A meta tag `google-site-verification` permanece vazia porque a propriedade foi verificada pelo arquivo HTML, não pelo método de meta tag. A propriedade verificada e a submissão do sitemap não garantem rastreamento ou indexação.

## Google Analytics 4

Foi criada a propriedade GA4 **CalculaFácil** e o fluxo Web **CalculaFácil — site público**, associado a `https://pedroicsan.github.io/calculafacil/`. O ID de medição gerado pelo Google é `G-47YHEZD21Z`. O fuso horário dos relatórios é Horário São Paulo (GMT-03:00), e a moeda é real brasileiro (BRL).

O fluxo está configurado para visualizações de página padrão. A medição otimizada de rolagens, cliques, formulários e outras interações foi desativada. A tag só é carregada quando a pessoa visitante aceita Analytics; a recusa bloqueia o carregamento e a preferência pode ser alterada em **Preferências de privacidade**, no rodapé. A primeira opção não é pré-selecionada.

O código envia ao GA4 apenas a URL da página sem parâmetros de consulta ou fragmentos e, quando há referenciador, somente a origem do site anterior. O CalculaFácil não lê nem envia valores digitados nas calculadoras. Os sinais do Google e a personalização de anúncios foram desativados na configuração da tag. A Política de Privacidade agora descreve essa integração e aponta para a política do Google.

O próprio assistente do Google informou que a coleta pode levar até 48 horas para começar. No momento da criação, o painel dizia que ainda não havia dados recebidos; a implementação publicada depende de uma visita real com consentimento afirmativo. Nenhuma visita de teste foi enviada para a propriedade.

Os valores `googleAnalyticsId` e `googleAnalyticsEnabled` estão em `src/data/site.config.json`. O ID de medição é público, como qualquer ID de tag inserido em um site, e não é uma senha ou chave secreta.

## Pendências externas do Search Console

A verificação da propriedade está concluída. O status de processamento do sitemap deve ser acompanhado no painel; a presença do arquivo e do HTTP 200 não comprova que o Google já terminou a leitura nem que indexou as páginas. A inclusão nos resultados permanece sob decisão dos sistemas de pesquisa do Google.

## Google AdSense

O AdSense continua **desativado**. Não há editor, slots publicitários reais, anúncios ativos ou aprovação presumida. Os espaços identificados como “Publicidade” são apenas reservas. Para uma ativação futura, o proprietário deverá criar/conectar uma conta, solicitar análise, aguardar aprovação, inserir os IDs legítimos e revisar as políticas, a Política de Privacidade e os avisos aplicáveis. Nenhum código de anúncios deve ser habilitado antes da aprovação e da revisão das divulgações necessárias.

## Afiliados, patrocínios e contato

`affiliateLinks` permanece vazio e não há parceria, produto, URL ou comissão inventada. A página **Anuncie no CalculaFácil** apresenta formatos possíveis sem declarar audiência ou resultados. `contactEmail` permanece vazio; só um endereço verdadeiro informado pelo proprietário pode ser exibido. O portal estático não armazena mensagens.

## Custos

Nenhum serviço pago, domínio, servidor, API, banco de dados ou assinatura foi ativado. O GA4 padrão foi configurado sem contratar um plano pago. As calculadoras continuam operando localmente no navegador, mesmo se Analytics, anúncios e afiliados estiverem desligados.

## Referências oficiais

- [Verificar a propriedade de um site no Search Console](https://support.google.com/webmasters/answer/9008080?hl=pt-BR)
- [Criar e enviar um sitemap ao Google](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap)
- [Configurar uma propriedade e fluxo de dados da Web no Google Analytics](https://support.google.com/analytics/answer/9304153?hl=pt-br)
- [Localizar o ID de medição do Google Analytics](https://support.google.com/analytics/answer/12270356?hl=pt-br)
- [Política de Privacidade do Google](https://policies.google.com/privacy?hl=pt-BR)
- [Conectar um site ao AdSense](https://support.google.com/adsense/answer/7584263?hl=pt-BR)
- [Políticas do programa AdSense](https://support.google.com/adsense/answer/48182?hl=pt-BR)
- [Qualificar links externos com `rel="sponsored"`](https://developers.google.com/search/docs/crawling-indexing/qualify-outbound-links)
