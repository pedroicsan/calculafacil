# Configuração futura de monetização e acompanhamento

O CalculaFácil está publicado em [https://pedroicsan.github.io/calculafacil/](https://pedroicsan.github.io/calculafacil/). Nenhuma monetização nem rastreamento está habilitado por padrão. Os passos abaixo só devem ser usados se o responsável decidir conectar uma conta externa; a publicação básica continua gratuita no GitHub Pages.

## Google Search Console

1. Entre no Search Console com a conta Google do proprietário e adicione uma propriedade de prefixo de URL para `https://pedroicsan.github.io/calculafacil/`.
2. Selecione a verificação por meta tag. Copie somente o valor de conteúdo exato fornecido pelo Google, sem inventar ou editar o token.
3. No código-fonte, abra `src/data/site.config.json` e preencha `googleSiteVerification` com esse valor. Gere novamente o ZIP e atualize o repositório. Depois que o workflow publicar a versão, conclua a verificação no Search Console.
4. Envie o sitemap `https://pedroicsan.github.io/calculafacil/sitemap.xml` na seção **Sitemaps** da propriedade. O sitemap facilita descobrir URLs, mas não garante rastreamento nem inclusão nos resultados.

A meta tag é entregue no HTML inicial da página. Mantenha o token no projeto enquanto a propriedade depender desse método de verificação.

## Google Analytics — opcional

Para usar GA4, crie uma propriedade legítima na conta do responsável, copie o ID de medição no formato `G-...` e configure `googleAnalyticsId` no `src/data/site.config.json`. Só mude `googleAnalyticsEnabled` para `true` depois de revisar a Política de Privacidade e as escolhas de consentimento aplicáveis. Com a configuração ativa, o script do Analytics só é carregado quando o visitante aceita; a recusa não carrega o script. O consentimento é guardado no navegador.

A implementação é opcional e não é necessária para cálculos, SEO, Search Console ou para manter o site publicado. O proprietário deve revisar as regras aplicáveis aos seus visitantes e ao tipo de medição antes da ativação. Não compartilhe IDs de medição em conversas públicas se não desejar que apareçam no código aberto do site.

## Google AdSense

1. O proprietário precisa criar uma conta AdSense, adicionar a URL pública do portal e seguir o método de conexão/verificação fornecido pela conta.
2. Solicite a revisão do site e aguarde a decisão do Google. A política e a aprovação são de responsabilidade do Google; não há aprovação, prazo ou receita garantidos.
3. Somente depois da aprovação, configure o ID de editor `ca-pub-...` em `adsenseClientId`, defina `adsEnabled` como `true` e informe os IDs numéricos legítimos em `adsSlots.homepage` e `adsSlots.calculator`.
4. Revise a Política de Privacidade, as mensagens/consentimento eventualmente exigidos para o público-alvo, as políticas vigentes de anúncio e eventuais instruções do AdSense, como um `ads.txt` específico da conta.
5. Gere, valide e publique o novo ZIP. Confira os anúncios em desktop e celular e assegure que a palavra “Publicidade” permaneça visível, que nenhum criativo pareça botão de cálculo/navegação e que os anúncios não bloqueiem a ferramenta.

Sem configuração válida e aprovação, os espaços exibem apenas um aviso de reserva e não requisitam anúncios. Nunca clique nos próprios anúncios nem peça a visitantes para clicarem.

## Links de afiliados

Para cada parceria, o proprietário deve primeiro se inscrever no programa, obter permissão e copiar o URL real HTTPS fornecido pelo parceiro. Depois, poderá preencher `affiliateLinks` em `src/data/site.config.json` com nome honesto, URL e a calculadora relacionada. A Fase 2 deixa esse formato vazio até haver dados verdadeiros. Links só serão renderizados quando tiverem rótulo e endereço válidos; serão identificados como recomendação comercial e usarão `rel="sponsored"` (com `nofollow` adicional).

Antes de publicar, adicione uma divulgação clara na página correspondente, confirme as regras do programa e atualize a Política de Privacidade e os Termos quando necessário. Não invente empresa, produto, preço, comissão ou relação de parceria.

## Contato comercial e patrocínios

A página **Anuncie no CalculaFácil** descreve possíveis formatos de parceria sem afirmar audiência, número de usuários ou desempenho. Para exibir um canal de contato, configure somente um e-mail verdadeiro em `contactEmail`. O site estático não recebe nem armazena mensagens e não possui formulário de contato.

## Custos e dependências

Search Console, Analytics e AdSense têm contas e condições próprias dos respectivos provedores. O usuário é quem decide se os ativa e cumpre seus requisitos. As instruções não compram domínio, não ligam rastreamento, não ativam anúncios nem adicionam checkout. As calculadoras continuam funcionando no navegador com todas essas opções desligadas.

## Referências oficiais

- [Verificar a propriedade de um site no Search Console](https://support.google.com/webmasters/answer/9008080?hl=pt-BR)
- [Criar e enviar um sitemap ao Google](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap)
- [Conectar um site ao AdSense](https://support.google.com/adsense/answer/7584263?hl=pt-BR)
- [Políticas do programa AdSense](https://support.google.com/adsense/answer/48182?hl=pt-BR)
- [Qualificar links externos com `rel="sponsored"`](https://developers.google.com/search/docs/crawling-indexing/qualify-outbound-links)
