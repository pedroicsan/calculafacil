# Auditoria inicial da versão pública — Fase 2

**Data da leitura:** 30/10/2026. **Endereço:** [https://pedroicsan.github.io/calculafacil/](https://pedroicsan.github.io/calculafacil/).

As páginas foram lidas pelo conteúdo HTML inicial servido publicamente, sem depender da execução do JavaScript. Os resultados são uma fotografia da publicação anterior à Fase 2.

## Estado observado

| Superfície | Resultado observado antes da Fase 2 |
|---|---|
| Página inicial | Apresentava as 15 calculadoras, 5 categorias e 8 atalhos de “Ferramentas populares”, com busca e espaço de anúncio reservado. |
| Página de consumo de energia | Já tinha formulário, instruções e fórmula de consumo. A seção FAQ continha apenas duas perguntas genéricas (“Como calcular…” e “O resultado é uma garantia…”); não havia exemplo numérico nem bloco dedicado de situações de uso. |
| `robots.txt` | `User-agent: *`, `Allow: /` e `Sitemap: https://pedroicsan.github.io/calculafacil/sitemap.xml`. |
| `sitemap.xml` | 25 URLs sob a origem e o caminho publicados: home, 15 calculadoras, 5 categorias e 4 páginas informativas. |

A extração da home também detectou no HTML a mensagem “Nenhuma ferramenta corresponde à pesquisa” antes de uma busca do visitante. Ela pode estar ocultada visualmente por CSS; de todo modo, será ajustada para que o estado vazio só apareça depois da pesquisa e continue acessível.

## Páginas e artefatos consultados

- Home: https://pedroicsan.github.io/calculafacil/
- Calculadora usada como amostra: https://pedroicsan.github.io/calculafacil/ferramentas/consumo-de-energia/
- Diretivas: https://pedroicsan.github.io/calculafacil/robots.txt
- Mapa de páginas: https://pedroicsan.github.io/calculafacil/sitemap.xml

## Verificação HTTP de referência

Em 30/10/2026, a home, a calculadora de consumo de energia e a categoria Casa e energia retornaram HTTP 200. Seus títulos, descriptions e canonicals apontavam para a origem real `https://pedroicsan.github.io/calculafacil/`; todas declaravam `index,follow` e tinham JSON-LD parseável. A home tinha 21.253 bytes de HTML, a calculadora 12.948 e a categoria 7.495 (sem contar CSS, JavaScript e imagens). O sitemap continha 25 URLs. Uma rota inventada retornou HTTP 404. A rota futura `/anuncie-no-calculafacil/` ainda não existia e retornou HTTP 404, conforme esperado antes da implementação.

Os tamanhos são apenas transferências locais observadas via HTTP em um momento; não representam LCP/INP/CLS de visitantes. Core Web Vitals de campo ainda não podem ser avaliados sem dados de Search Console/CrUX.
