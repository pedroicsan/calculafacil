# Hospedagem estática gratuita: GitHub Pages

A documentação oficial descreve o GitHub Pages como hospedagem estática de HTML, CSS e JavaScript, com possibilidade de gerar os arquivos durante a publicação. Uma página de projeto usa normalmente `https://<dono>.github.io/<nome-do-repositório>/`; uma página de usuário/organização usa um repositório chamado `<dono>.github.io` e publica na raiz.

No GitHub Free, o repositório que hospeda o site precisa ser público. O site publicado é acessível publicamente. A documentação também informa que o GitHub registra o endereço IP dos visitantes para fins de segurança, estejam eles conectados ao GitHub ou não. Por isso, a Política de Privacidade do CalculaFácil deve mencionar os registros técnicos do provedor se esta opção for usada.

Para um fluxo personalizado com GitHub Actions, a configuração do repositório deve usar **Settings → Pages → Build and deployment → GitHub Actions**. O fluxo deve construir a pasta estática, enviar um artefato Pages e implantá-lo em um job dependente do build. A documentação atual indica `actions/upload-pages-artifact@v4` e `actions/deploy-pages@v4`; o job de implantação precisa das permissões `pages: write` e `id-token: write`, e deve usar o ambiente `github-pages`.

O GitHub Pages aceita domínio próprio. Um subdomínio costuma usar DNS `CNAME`; um domínio raiz pode usar `A`, `ALIAS` ou `ANAME`, conforme o provedor DNS. O domínio é opcional e não será comprado neste projeto. Se for adicionado depois, o domínio e os registros DNS devem ser configurados pelo proprietário da conta.

## Fontes oficiais consultadas

- [GitHub Pages: visão geral, tipos de site e registros de IP](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)
- [Criar um site GitHub Pages e requisito de repositório público no GitHub Free](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [Fluxos personalizados de GitHub Actions para Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)
- [Configurar a origem de publicação](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
- [Domínios personalizados e DNS](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/about-custom-domains-and-github-pages)

## Publicação atual

O CalculaFácil está publicado em [https://pedroicsan.github.io/calculafacil/](https://pedroicsan.github.io/calculafacil/) pelo repositório público [pedroicsan/calculafacil](https://github.com/pedroicsan/calculafacil). O workflow **Publish CalculaFácil** executa os testes, gera o site estático e publica o artefato no GitHub Pages; o primeiro deployment terminou com sucesso. A publicação é pública, não depende de domínio próprio nem de hospedagem paga. O proprietário pode preencher `contactEmail` no arquivo `src/data/site.config.json`; sem isso, a página Contato informa que o endereço ainda não foi configurado e não coleta mensagens.
