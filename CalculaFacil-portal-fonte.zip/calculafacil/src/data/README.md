# Configuração pública do site

`site.config.json` é incorporado ao HTML gerado e, portanto, todo valor inserido nele poderá ser lido publicamente. Não coloque segredos, senhas, tokens privados nem dados pessoais que não devam ser exibidos.

A versão inicial mantém vazios o contato, Google Analytics, Search Console, AdSense, espaços publicitários e links de afiliados. Só habilite integrações após obter identificadores legítimos e revisar a Política de Privacidade.
