import { calculate, getUnitOptions } from "./calculators.mjs";

const numberFormat = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 6 });
const currencyFormat = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  minimumFractionDigits: 2,
  maximumFractionDigits: 4
});

function normalizedText(value) {
  return String(value ?? "")
    .toLocaleLowerCase("pt-BR")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function readSiteConfig() {
  const configElement = document.querySelector("#site-config");
  if (!configElement) return {};
  try { return JSON.parse(configElement.textContent || "{}"); }
  catch { return {}; }
}

function formatMetric(item) {
  if (item.format === "currency") return currencyFormat.format(item.value);
  if (item.format === "number") {
    const unit = item.unit ? ` ${item.unit}` : "";
    return `${numberFormat.format(item.value)}${unit}`;
  }
  return String(item.value);
}

function updateUnitSelectors(form) {
  const category = form.elements.namedItem("category")?.value;
  const options = getUnitOptions(category);
  for (const name of ["fromUnit", "toUnit"]) {
    const select = form.elements.namedItem(name);
    if (!select) continue;
    const oldValue = select.value;
    select.replaceChildren(new Option("Selecione uma unidade", ""));
    for (const item of options) select.add(new Option(item.label, item.value));
    if (options.some((item) => item.value === oldValue)) select.value = oldValue;
  }
}

function renderPrompt(panel, message = "Preencha os campos para ver o resultado. Seus dados são calculados neste navegador.") {
  const summary = panel.querySelector("[data-result-summary]");
  const metrics = panel.querySelector("[data-result-metrics]");
  const explanation = panel.querySelector("[data-result-explanation]");
  const error = panel.querySelector("[data-result-error]");
  summary.textContent = "Seu resultado aparece aqui";
  metrics.replaceChildren();
  explanation.textContent = message;
  error.hidden = true;
  error.textContent = "";
}

function renderError(panel, message) {
  renderPrompt(panel, "Confira os campos e ajuste os valores informados.");
  const error = panel.querySelector("[data-result-error]");
  error.textContent = message;
  error.hidden = false;
}

function renderCalculation(panel, result) {
  panel.querySelector("[data-result-summary]").textContent = result.summary;
  panel.querySelector("[data-result-explanation]").textContent = result.explanation;
  panel.querySelector("[data-result-error]").hidden = true;
  const list = panel.querySelector("[data-result-metrics]");
  list.replaceChildren();

  for (const item of result.metrics) {
    const row = document.createElement("div");
    row.className = `metric-row${item.highlight ? " is-highlight" : ""}`;
    const label = document.createElement("dt");
    label.textContent = item.label;
    const value = document.createElement("dd");
    value.textContent = formatMetric(item);
    row.append(label, value);
    list.append(row);
  }
}

function setupCalculator() {
  const form = document.querySelector("[data-calculator-form]");
  const panel = document.querySelector("[data-result-panel]");
  if (!form || !panel) return;

  const type = form.dataset.calculatorType;
  const requiredFields = [...form.querySelectorAll("[name]")]
    .filter((field) => field.required)
    .map((field) => field.name);
  let submitted = false;

  const update = () => {
    if (form.elements.namedItem("category")) updateUnitSelectors(form);
    const values = Object.fromEntries(new FormData(form).entries());
    const complete = requiredFields.every((name) => String(values[name] ?? "").trim() !== "");
    if (!complete && !submitted) {
      renderPrompt(panel);
      return;
    }
    try {
      renderCalculation(panel, calculate(type, values));
    } catch (error) {
      if (complete || submitted) renderError(panel, error instanceof Error ? error.message : "Revise os dados informados.");
      else renderPrompt(panel);
    }
  };

  form.addEventListener("input", update);
  form.addEventListener("change", update);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    submitted = true;
    update();
  });
  form.addEventListener("reset", () => {
    submitted = false;
    window.setTimeout(() => {
      if (form.elements.namedItem("category")) updateUnitSelectors(form);
      renderPrompt(panel);
    }, 0);
  });
  update();
}

function setupSearch() {
  const inputs = [...document.querySelectorAll("[data-site-search]")];
  const cards = [...document.querySelectorAll("[data-search-card]")];
  const emptyState = document.querySelector("[data-search-empty]");
  const queryFromUrl = new URLSearchParams(window.location.search).get("q") ?? "";

  if (queryFromUrl) {
    for (const input of inputs) input.value = queryFromUrl;
  }

  const filter = (query) => {
    if (!cards.length) return;
    const normalizedQuery = normalizedText(query.trim());
    let visible = 0;
    for (const card of cards) {
      const match = !normalizedQuery || normalizedText(card.dataset.searchCard).includes(normalizedQuery);
      card.hidden = !match;
      if (match) visible += 1;
    }
    if (emptyState) emptyState.classList.toggle("is-visible", visible === 0);
  };

  for (const input of inputs) {
    input.addEventListener("input", () => {
      filter(input.value);
      for (const other of inputs) if (other !== input) other.value = input.value;
    });
  }
  filter(queryFromUrl);
}

function setupContactEmail(config) {
  const emailElements = document.querySelectorAll("[data-contact-email]");
  const email = typeof config.contactEmail === "string" ? config.contactEmail.trim() : "";
  for (const element of emailElements) {
    if (!email) continue;
    const link = document.createElement("a");
    link.className = "contact-email";
    link.href = `mailto:${email}`;
    link.textContent = email;
    element.replaceChildren(link);
  }
}

function loadGoogleAnalytics(measurementId) {
  if (window.__calculafacilAnalyticsLoaded) return;
  window.__calculafacilAnalyticsLoaded = true;
  window.dataLayer = window.dataLayer || [];
  window.gtag = function gtag() { window.dataLayer.push(arguments); };
  window.gtag("js", new Date());
  window.gtag("config", measurementId);
  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(measurementId)}`;
  document.head.append(script);
}

function setupAnalytics(config) {
  const measurementId = typeof config.googleAnalyticsId === "string" ? config.googleAnalyticsId.trim() : "";
  if (config.googleAnalyticsEnabled !== true || !/^G-[A-Z0-9]{4,20}$/i.test(measurementId)) return;
  const consentKey = "calculafacil-google-analytics-consent";
  const disableKey = `ga-disable-${measurementId}`;
  let choice = "";
  try { choice = localStorage.getItem(consentKey) || ""; } catch { /* Consent can still be chosen for this visit. */ }
  if (choice === "accepted") {
    window[disableKey] = false;
    loadGoogleAnalytics(measurementId);
  } else if (choice === "rejected") {
    window[disableKey] = true;
  }

  const settings = document.querySelector("[data-analytics-settings]");
  if (settings) {
    settings.hidden = false;
    settings.addEventListener("click", showConsentChoices);
  }
  if (!choice) showConsentChoices();

  function showConsentChoices() {
    if (document.querySelector(".privacy-consent")) return;
    const banner = document.createElement("section");
    banner.className = "privacy-consent";
    banner.setAttribute("role", "region");
    banner.setAttribute("aria-label", "Escolha de analytics");
    const message = document.createElement("p");
    message.append("O Google Analytics só será carregado após consentimento. Você pode aceitar ou recusar e alterar a escolha no rodapé. ");
    const policyLink = document.createElement("a");
    const publicBase = document.querySelector("base")?.href || window.location.href;
    policyLink.href = new URL("privacidade/", publicBase).href;
    policyLink.textContent = "Leia a Política de Privacidade.";
    message.append(policyLink);
    const actions = document.createElement("div");
    actions.className = "privacy-consent-actions";
    const accept = document.createElement("button");
    accept.type = "button";
    accept.textContent = "Aceitar analytics";
    const reject = document.createElement("button");
    reject.type = "button";
    reject.className = "secondary-button";
    reject.textContent = "Recusar";
    accept.addEventListener("click", () => {
      try { localStorage.setItem(consentKey, "accepted"); } catch { /* Apply only for this visit. */ }
      window[disableKey] = false;
      loadGoogleAnalytics(measurementId);
      banner.remove();
    });
    reject.addEventListener("click", () => {
      try { localStorage.setItem(consentKey, "rejected"); } catch { /* Apply only for this visit. */ }
      window[disableKey] = true;
      banner.remove();
    });
    actions.append(accept, reject);
    banner.append(message, actions);
    document.body.append(banner);
  }
}

function setupAds(config) {
  const client = typeof config.adsenseClientId === "string" ? config.adsenseClientId.trim() : "";
  if (config.adsEnabled !== true || !/^ca-pub-\d{16}$/.test(client)) return;
  const zones = [...document.querySelectorAll("[data-ad-zone]")];
  const ready = zones.filter((zone) => /^\d{5,20}$/.test(zone.dataset.adSlot || ""));
  if (!ready.length) return;

  const script = document.createElement("script");
  script.async = true;
  script.crossOrigin = "anonymous";
  script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(client)}`;
  script.addEventListener("load", () => {
    for (const zone of ready) {
      const ad = document.createElement("ins");
      ad.className = "adsbygoogle";
      ad.style.display = "block";
      ad.dataset.adClient = client;
      ad.dataset.adSlot = zone.dataset.adSlot;
      ad.dataset.adFormat = "auto";
      ad.setAttribute("data-full-width-responsive", "true");
      const label = zone.querySelector(".ad-label");
      zone.replaceChildren();
      if (label) zone.append(label);
      zone.append(ad);
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch { /* Ad delivery can be unavailable or blocked. */ }
    }
  });
  document.head.append(script);
}

function setupOfflineSupport() {
  if (!("serviceWorker" in navigator)) return;
  const base = document.querySelector("base")?.href;
  if (!base) return;
  const workerUrl = new URL("sw.js", base);
  navigator.serviceWorker.register(workerUrl, { scope: base }).catch(() => {
    // A browser, private mode or non-HTTPS origin may disable service workers.
  });
}

const siteConfig = readSiteConfig();
setupCalculator();
setupSearch();
setupContactEmail(siteConfig);
setupAnalytics(siteConfig);
setupAds(siteConfig);
setupOfflineSupport();
