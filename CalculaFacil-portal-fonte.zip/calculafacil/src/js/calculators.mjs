const UNIT_GROUPS = {
  length: {
    m: { label: "Metro (m)", factor: 1 },
    km: { label: "Quilômetro (km)", factor: 1000 },
    cm: { label: "Centímetro (cm)", factor: 0.01 },
    mm: { label: "Milímetro (mm)", factor: 0.001 },
    mi: { label: "Milha (mi)", factor: 1609.344 },
    ft: { label: "Pé (ft)", factor: 0.3048 },
    in: { label: "Polegada (in)", factor: 0.0254 }
  },
  mass: {
    kg: { label: "Quilograma (kg)", factor: 1 },
    g: { label: "Grama (g)", factor: 0.001 },
    mg: { label: "Miligrama (mg)", factor: 0.000001 },
    lb: { label: "Libra (lb)", factor: 0.45359237 },
    oz: { label: "Onça (oz)", factor: 0.028349523125 }
  },
  volume: {
    L: { label: "Litro (L)", factor: 1 },
    ml: { label: "Mililitro (ml)", factor: 0.001 },
    m3: { label: "Metro cúbico (m³)", factor: 1000 },
    galUS: { label: "Galão dos EUA (gal)", factor: 3.785411784 }
  },
  temperature: {
    C: { label: "Celsius (°C)" },
    F: { label: "Fahrenheit (°F)" },
    K: { label: "Kelvin (K)" }
  }
};

const WEIGHT_VOLUME_UNITS = {
  kg: { group: "mass", factor: 1, label: "kg" },
  g: { group: "mass", factor: 0.001, label: "g" },
  L: { group: "volume", factor: 1, label: "L" },
  ml: { group: "volume", factor: 0.001, label: "ml" },
  un: { group: "count", factor: 1, label: "unidade" }
};

function numberValue(values, key, label, { optional = false, min = -Infinity, max = Infinity, integer = false } = {}) {
  const raw = values[key];
  if ((raw === undefined || raw === null || raw === "") && optional) return 0;
  if (raw === undefined || raw === null || raw === "") throw new Error(`Informe ${label.toLowerCase()}.`);
  const value = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  if (!Number.isFinite(value)) throw new Error(`${label} precisa ser um número válido.`);
  if (value < min) throw new Error(`${label} precisa ser ${min === 0 ? "zero ou maior" : `maior ou igual a ${min}`}.`);
  if (value > max) throw new Error(`${label} não pode ser maior que ${max}.`);
  if (integer && !Number.isInteger(value)) throw new Error(`${label} precisa ser um número inteiro.`);
  return value;
}

function selection(values, key, label) {
  const value = values[key];
  if (typeof value !== "string" || value.length === 0) throw new Error(`Selecione ${label.toLowerCase()}.`);
  return value;
}

function output(summary, metrics, explanation) {
  return { summary, metrics, explanation };
}

function metric(label, value, format = "number", unit = "", highlight = false) {
  return { label, value, format, unit, highlight };
}

function normalizedQuantity(quantity, unit) {
  const definition = WEIGHT_VOLUME_UNITS[unit];
  if (!definition) throw new Error("Selecione uma unidade de quantidade válida.");
  return { value: quantity * definition.factor, group: definition.group, label: definition.label };
}

function normalizedUnitPrice(price, quantity, unit) {
  const normalized = normalizedQuantity(quantity, unit);
  if (normalized.value <= 0) throw new Error("A quantidade do produto precisa ser maior que zero.");
  const baseLabel = normalized.group === "mass" ? "kg" : normalized.group === "volume" ? "L" : "unidade";
  return { price: price / normalized.value, group: normalized.group, baseLabel };
}

function formatWinner(valueA, valueB, nameA = "Opção A", nameB = "Opção B") {
  if (Math.abs(valueA - valueB) < 1e-10) return "As duas opções têm o mesmo custo.";
  return valueA < valueB ? `${nameA} tem o menor custo.` : `${nameB} tem o menor custo.`;
}

function convertTemperature(value, from, to) {
  let celsius;
  if (from === "C") celsius = value;
  else if (from === "F") celsius = (value - 32) * 5 / 9;
  else if (from === "K") celsius = value - 273.15;
  else throw new Error("Selecione uma unidade de temperatura válida.");

  if (to === "C") return celsius;
  if (to === "F") return celsius * 9 / 5 + 32;
  if (to === "K") {
    const kelvin = celsius + 273.15;
    if (kelvin < 0) throw new Error("A temperatura convertida não pode ser menor que zero kelvin.");
    return kelvin;
  }
  throw new Error("Selecione uma unidade de temperatura válida.");
}

function calculateEnergy(values) {
  const power = numberValue(values, "powerW", "A potência", { min: 0.000001 });
  const hours = numberValue(values, "hoursPerDay", "As horas por dia", { min: 0, max: 24 });
  const days = numberValue(values, "daysPerMonth", "Os dias de uso no mês", { min: 0, max: 31 });
  const tariff = numberValue(values, "pricePerKwh", "A tarifa", { min: 0 });
  const kwh = power / 1000 * hours * days;
  const cost = kwh * tariff;
  return output("Estimativa mensal do aparelho", [
    metric("Consumo no período", kwh, "number", "kWh"),
    metric("Custo estimado", cost, "currency", "", true)
  ], `A conta considera ${power} W, ${hours} hora(s) por dia, ${days} dia(s) e tarifa de R$ ${tariff} por kWh.`);
}

function calculateFuel(values) {
  const distance = numberValue(values, "distanceKm", "A distância", { min: 0.000001 });
  const trips = numberValue(values, "tripCount", "A quantidade de trechos", { min: 1, integer: true });
  const efficiency = numberValue(values, "kmPerLiter", "O consumo do veículo", { min: 0.000001 });
  const price = numberValue(values, "fuelPrice", "O preço do combustível", { min: 0 });
  const liters = distance * trips / efficiency;
  const cost = liters * price;
  return output("Estimativa de combustível", [
    metric("Distância total considerada", distance * trips, "number", "km"),
    metric("Combustível estimado", liters, "number", "L"),
    metric("Custo estimado", cost, "currency", "", true)
  ], `O cálculo usa ${trips} trecho(s) de ${distance} km e consumo informado de ${efficiency} km/L.`);
}

function calculatePriceCompare(values) {
  const priceA = numberValue(values, "priceA", "O preço da opção A", { min: 0 });
  const quantityA = numberValue(values, "quantityA", "A quantidade da opção A", { min: 0.000001 });
  const unitA = selection(values, "unitA", "a unidade da opção A");
  const priceB = numberValue(values, "priceB", "O preço da opção B", { min: 0 });
  const quantityB = numberValue(values, "quantityB", "A quantidade da opção B", { min: 0.000001 });
  const unitB = selection(values, "unitB", "a unidade da opção B");
  const normalizedA = normalizedUnitPrice(priceA, quantityA, unitA);
  const normalizedB = normalizedUnitPrice(priceB, quantityB, unitB);
  if (normalizedA.group !== normalizedB.group) throw new Error("Escolha unidades da mesma família para comparar: massa, volume ou unidade.");
  return output(formatWinner(normalizedA.price, normalizedB.price), [
    metric(`Opção A por ${normalizedA.baseLabel}`, normalizedA.price, "currency"),
    metric(`Opção B por ${normalizedB.baseLabel}`, normalizedB.price, "currency"),
    metric("Menor preço normalizado", Math.min(normalizedA.price, normalizedB.price), "currency", `por ${normalizedA.baseLabel}`, true)
  ], "Os preços foram divididos pela quantidade convertida para a unidade-base correspondente.");
}

function calculateDiscount(values) {
  const original = numberValue(values, "originalPrice", "O preço original", { min: 0 });
  const percent = numberValue(values, "percentDiscount", "O desconto percentual", { min: 0, max: 100 });
  const fixed = numberValue(values, "fixedDiscount", "O desconto fixo", { min: 0, optional: true });
  const savedPercent = original * percent / 100;
  const finalPercent = Math.max(0, original - savedPercent);
  const savedFixed = Math.min(original, fixed);
  const finalFixed = Math.max(0, original - savedFixed);
  const summary = finalPercent === finalFixed ? "As duas ofertas deixam o mesmo preço final." : finalPercent < finalFixed ? "O desconto percentual deixa o menor preço final." : "O desconto fixo deixa o menor preço final.";
  return output(summary, [
    metric("Com desconto percentual", finalPercent, "currency", "", finalPercent <= finalFixed),
    metric("Economia percentual", savedPercent, "currency"),
    metric("Com desconto fixo", finalFixed, "currency", "", finalFixed < finalPercent),
    metric("Economia fixa", savedFixed, "currency")
  ], "Cada promoção foi calculada separadamente sobre o preço original. O preço final não fica negativo.");
}

function calculatePercentage(values) {
  const percentage = numberValue(values, "percentage", "A porcentagem", { min: 0 });
  const base = numberValue(values, "baseValue", "O valor-base", { min: 0 });
  const amount = percentage * base / 100;
  return output("Resultado da porcentagem", [metric(`${percentage}% do valor informado`, amount, "number", "", true)], `A operação foi ${base} × ${percentage} ÷ 100.`);
}

function calculateHourlySalary(values) {
  const salary = numberValue(values, "monthlySalary", "O salário mensal", { min: 0 });
  const hours = numberValue(values, "monthlyHours", "As horas trabalhadas no mês", { min: 0.000001 });
  const hourly = salary / hours;
  return output("Média por hora", [
    metric("Valor médio por hora", hourly, "currency", "", true),
    metric("Salário mensal informado", salary, "currency"),
    metric("Horas no mês", hours, "number", "h")
  ], "O valor por hora é uma divisão bruta e não inclui descontos, benefícios ou adicionais.");
}

function calculateExpenseSplit(values) {
  const total = numberValue(values, "totalExpenses", "O total das despesas", { min: 0 });
  const people = numberValue(values, "participants", "O número de participantes", { min: 1, integer: true });
  const share = total / people;
  return output("Divisão igual", [
    metric("Valor por pessoa", share, "currency", "", true),
    metric("Total dividido", total, "currency"),
    metric("Participantes", people, "number", "pessoas")
  ], `O total foi dividido igualmente entre ${people} participante(s).`);
}

function calculateMonthlySavings(values) {
  const target = numberValue(values, "targetAmount", "A meta", { min: 0.000001 });
  const current = numberValue(values, "currentSavings", "O valor já guardado", { min: 0, optional: true });
  const monthly = numberValue(values, "monthlyDeposit", "O valor que pretende guardar por mês", { min: 0 });
  const remaining = Math.max(0, target - current);
  if (remaining > 0 && monthly <= 0) throw new Error("Informe uma economia mensal maior que zero para estimar o prazo.");
  const months = remaining === 0 ? 0 : Math.ceil(remaining / monthly);
  const projected = current + months * monthly;
  return output(remaining === 0 ? "Você já alcançou a meta informada." : "Prazo estimado para a meta", [
    metric("Meses estimados", months, "number", months === 1 ? "mês" : "meses", true),
    metric("Valor que falta", remaining, "currency"),
    metric("Saldo estimado ao final", projected, "currency")
  ], "A estimativa não inclui rendimentos, inflação ou alterações nos depósitos mensais.");
}

function calculateUnitConverter(values) {
  const category = selection(values, "category", "o tipo de medida");
  const value = numberValue(values, "value", "O valor para converter");
  const from = selection(values, "fromUnit", "a unidade de origem");
  const to = selection(values, "toUnit", "a unidade de destino");
  const group = UNIT_GROUPS[category];
  if (!group || !(from in group) || !(to in group)) throw new Error("Confira a categoria e as unidades selecionadas.");
  let converted;
  if (category === "temperature") {
    if (from === "K" && value < 0) throw new Error("Kelvin não pode ser menor que zero.");
    converted = convertTemperature(value, from, to);
  } else {
    converted = value * group[from].factor / group[to].factor;
  }
  const fromLabel = group[from].label;
  const toLabel = group[to].label;
  return output("Conversão concluída", [metric("Resultado", converted, "number", toLabel, true)], `${value} ${fromLabel} corresponde a ${converted} ${toLabel}.`);
}

function calculatePercentChange(values) {
  const base = numberValue(values, "baseValue", "O valor inicial", { min: 0 });
  const percent = numberValue(values, "changePercent", "O percentual", { min: 0 });
  const direction = selection(values, "direction", "o tipo de variação");
  if (direction === "decrease" && percent > 100) throw new Error("A redução não pode ultrapassar 100% do valor inicial.");
  const delta = base * percent / 100;
  let finalValue;
  if (direction === "increase") finalValue = base + delta;
  else if (direction === "decrease") finalValue = base - delta;
  else throw new Error("Selecione aumento ou redução.");
  return output(direction === "increase" ? "Valor após o aumento" : "Valor após a redução", [
    metric("Diferença", delta, "number", "", true),
    metric("Novo valor", finalValue, "number", "", true),
    metric("Valor inicial", base, "number")
  ], `Foi aplicada uma ${direction === "increase" ? "soma" : "subtração"} de ${percent}% ao valor inicial.`);
}

function calculateSimpleInterest(values) {
  const principal = numberValue(values, "principal", "O capital inicial", { min: 0 });
  const ratePercent = numberValue(values, "ratePercent", "A taxa por período", { min: 0 });
  const periods = numberValue(values, "periods", "O número de períodos", { min: 0 });
  const periodName = selection(values, "periodName", "a unidade de tempo");
  const interest = principal * (ratePercent / 100) * periods;
  const total = principal + interest;
  return output("Resultado com juros simples", [
    metric("Juros acumulados", interest, "currency"),
    metric("Montante total", total, "currency", "", true)
  ], `Foi usada a taxa de ${ratePercent}% por ${periodName}, durante ${periods} período(s). A periodicidade da taxa e do prazo precisa coincidir.`);
}

function calculateTripCost(values) {
  const distance = numberValue(values, "distanceKm", "A distância total", { min: 0 });
  const efficiency = numberValue(values, "kmPerLiter", "O consumo do veículo", { min: 0.000001 });
  const fuelPrice = numberValue(values, "fuelPrice", "O preço do combustível", { min: 0 });
  const extras = ["tolls", "lodging", "food", "otherCosts"].map((key) => numberValue(values, key, key === "tolls" ? "Os pedágios" : key === "lodging" ? "A hospedagem" : key === "food" ? "A alimentação" : "Os outros custos", { min: 0, optional: true }));
  const fuelLiters = distance / efficiency;
  const fuel = fuelLiters * fuelPrice;
  const additional = extras.reduce((sum, value) => sum + value, 0);
  const total = fuel + additional;
  return output("Estimativa do custo da viagem", [
    metric("Combustível estimado", fuel, "currency"),
    metric("Outras despesas", additional, "currency"),
    metric("Total estimado", total, "currency", "", true),
    metric("Litros necessários", fuelLiters, "number", "L")
  ], "O total soma o combustível e as despesas adicionais que você informou. Custos em branco foram considerados como zero.");
}

function calculateProductSavings(values) {
  const priceA = numberValue(values, "priceA", "O preço do produto A", { min: 0 });
  const shippingA = numberValue(values, "shippingA", "O frete da opção A", { min: 0, optional: true });
  const priceB = numberValue(values, "priceB", "O preço do produto B", { min: 0 });
  const shippingB = numberValue(values, "shippingB", "O frete da opção B", { min: 0, optional: true });
  const totalA = priceA + shippingA;
  const totalB = priceB + shippingB;
  return output(formatWinner(totalA, totalB), [
    metric("Total da opção A", totalA, "currency", "", totalA < totalB),
    metric("Total da opção B", totalB, "currency", "", totalB < totalA),
    metric("Diferença entre as opções", Math.abs(totalA - totalB), "currency", "", true)
  ], "A comparação considera produtos equivalentes e soma o frete informado a cada opção.");
}

function calculatePriceQuantity(values) {
  const price = numberValue(values, "packagePrice", "O preço da embalagem", { min: 0 });
  const packageQuantity = numberValue(values, "packageQuantity", "A quantidade da embalagem", { min: 0.000001 });
  const unit = selection(values, "quantityUnit", "a unidade de quantidade");
  const desired = numberValue(values, "desiredQuantity", "A quantidade desejada", { min: 0 });
  const normalizedPackage = normalizedQuantity(packageQuantity, unit);
  const normalizedDesired = normalizedQuantity(desired, unit);
  const unitPrice = price / normalizedPackage.value;
  const total = unitPrice * normalizedDesired.value;
  return output("Preço proporcional", [
    metric(`Preço por ${normalizedPackage.label}`, unitPrice, "currency"),
    metric(`Custo de ${desired} ${unit}`, total, "currency", "", true)
  ], "O cálculo assume que o preço varia proporcionalmente à quantidade. Promoções, embalagens fracionadas e taxas adicionais não estão incluídas.");
}

const CALCULATORS = {
  energy: calculateEnergy,
  fuel: calculateFuel,
  priceCompare: calculatePriceCompare,
  discount: calculateDiscount,
  percentage: calculatePercentage,
  hourlySalary: calculateHourlySalary,
  expenseSplit: calculateExpenseSplit,
  monthlySavings: calculateMonthlySavings,
  unitConverter: calculateUnitConverter,
  applianceCost: calculateEnergy,
  percentChange: calculatePercentChange,
  simpleInterest: calculateSimpleInterest,
  tripCost: calculateTripCost,
  productSavings: calculateProductSavings,
  priceQuantity: calculatePriceQuantity
};

export function getUnitOptions(category) {
  const options = UNIT_GROUPS[category];
  if (!options) return [];
  return Object.entries(options).map(([value, definition]) => ({ value, label: definition.label }));
}

export function calculate(type, values) {
  const calculator = CALCULATORS[type];
  if (!calculator) throw new Error("Esta ferramenta ainda não está disponível.");
  return calculator(values);
}
