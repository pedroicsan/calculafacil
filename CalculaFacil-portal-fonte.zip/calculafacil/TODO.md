# TODO — CalculaFácil

## Fase 1 — portal inicial (concluída)

- [x] Implementar todas as ferramentas obrigatórias e mostrar resultados instantâneos: consumo de energia elétrica; custo de combustível para viagens; comparação de preço por quilo, litro e unidade; descontos e promoções; porcentagem; salário por hora; divisão de despesas; economia mensal; conversor de medidas; custo de eletrodomésticos; aumento e redução percentual; juros simples; custo de uma viagem; economia entre produtos; preço por quantidade.
- [x] Explicar cada cálculo de maneira simples. Não utilizar dados inventados; quando o cálculo depender de informações variáveis, permitir que o visitante informe os valores.
- [x] Executar os cálculos diretamente no navegador, sem depender de login, banco de dados, chamadas de IA, APIs externas ou intervenção humana.
- [x] Criar a página inicial com todas as ferramentas, uma página individual para cada calculadora, categorias, campo de pesquisa, ferramentas populares, Sobre, Contato, Política de Privacidade e Termos de Uso.
- [x] Aplicar a identidade visual CalculaFácil, o slogan “Ferramentas gratuitas para facilitar sua vida.” e as cores #1769AA, #103B63, #FFFFFF, #F4F6F8 e #16865B; tornar o site responsivo em celulares.
- [x] Não contratar serviços, comprar domínio, usar APIs pagas, hospedagem paga, assinaturas ou funcionalidades com cobrança. Não usar hospedagem Manus paga como dependência; entregar fontes portáteis e preparar GitHub Pages gratuito.
- [x] Preparar URLs amigáveis, metadados exclusivos, sitemap, robots.txt, dados estruturados, links internos, conteúdo explicativo, acessibilidade e experiência mobile; manter Analytics e anúncios desativados até configuração legítima.
- [x] Preparar espaços identificados para publicidade e links de afiliados sem anúncios, aprovações, IDs, parcerias ou URLs falsos; manter cálculos independentes de anúncios.
- [x] Testar fórmulas, entradas inválidas/vazias/decimais, navegação, responsividade, velocidade e acesso offline depois do primeiro carregamento.
- [x] Publicar em [https://pedroicsan.github.io/calculafacil/](https://pedroicsan.github.io/calculafacil/) no repositório público [pedroicsan/calculafacil](https://github.com/pedroicsan/calculafacil), sem compra de domínio ou ativação de serviço pago.

## Fase 2 — otimização orgânica e monetização (concluída)

### 1. Auditoria de conteúdo das 15 ferramentas existentes
- [x] Fazer revisão individual de todas as páginas públicas, especialmente as 15 calculadoras. Para cada uma, identificar palavra-chave principal, palavras-chave secundárias, variações naturais, dúvidas relacionadas e pesquisas de cauda longa sem inventar volume de busca.
- [x] Ajustar título SEO e meta description para intenção de busca; criar introdução original e específica; explicar uso, fórmula e exemplos práticos; indicar situações reais em que ajuda; adicionar links internos relevantes.
- [x] Remover a repetição de perguntas frequentes e respostas genéricas; cada calculadora recebe perguntas e respostas próprias, relacionadas à finalidade e a dúvidas reais. Não usar texto genérico para aumentar tamanho, keyword stuffing ou páginas duplicadas.
- [x] Conferir cada explicação, exemplo e resposta com a fórmula executada pela calculadora.

### 2. Expansão seletiva
- [x] Pesquisar oportunidades adicionais com utilidade e intenção de busca orgânica nas áreas de finanças pessoais, economia doméstica, comparação de compras, energia, construção/reformas, viagens/transporte, salários/trabalho, matemática cotidiana e conversões.
- [x] Implementar somente ferramentas que resolvam problema específico, tenham finalidade diferente das atuais e potencial de busca próprio, fórmula confiável e conteúdo claro; operar no navegador, sem APIs pagas, IA, login ou banco de dados, com página individual, conteúdo original e SEO próprio. Priorizar qualidade e não quantidade; justificar as ferramentas adicionadas.

### 3. SEO técnico e indexabilidade
- [x] Verificar indexabilidade das páginas importantes, URLs amigáveis, canonical correto, sitemap XML atualizado com URLs reais, robots.txt, títulos/descrições exclusivos, hierarquia H1/H2/H3, links internos, breadcrumbs quando apropriado e dados estruturados válidos e fiéis ao conteúdo.
- [x] Verificar imagens otimizadas com textos alternativos, velocidade de carregamento, Core Web Vitals, experiência mobile, acessibilidade e ausência de links quebrados ou erros de navegação.
- [x] Verificar se cada página tem conteúdo suficiente e útil para merecer indexação. Não inventar avaliações, estrelas, comentários, autores, estatísticas ou qualquer informação; não implementar marcação estruturada incompatível com o conteúdo.

### 4. Google AdSense
- [x] Revisar e preparar espaços publicitários responsivos, identificados claramente como publicidade, na página inicial e nas páginas de calculadoras; evitar excesso em celular, clique acidental e interferência nos cálculos.
- [x] Manter anúncios desativados até existir conta aprovada e identificadores legítimos fornecidos pelo proprietário. Não inventar IDs nem simular aprovação.
- [x] Documentar as etapas para ativação do AdSense e atualizar a Política de Privacidade para publicidade e terceiros antes de habilitar qualquer código.

### 5. Afiliados
- [x] Identificar oportunidades contextuais para comparadores de produtos, economia doméstica, eficiência energética, viagens e serviços financeiros adequados, sem promessas de ganhos.
- [x] Preparar recomendações comerciais próprias para páginas relevantes, com identificação clara e `rel="sponsored"` quando aplicável; manter estrutura vazia/desativada até receber links legítimos.
- [x] Não inventar parceiros, produtos, preços, comissões ou links; não inserir links inexistentes.

### 6. Patrocínios diretos
- [x] Criar a página “Anuncie no CalculaFácil” ou “Seja um parceiro”, apresentando o portal e suas categorias e explicando formatos possíveis de parceria, publicidade e patrocínio.
- [x] Mostrar canal de contato somente se houver endereço verdadeiro configurado. Não inventar audiência, visitantes, resultados, parceiros, estatísticas nem prometer alcance não comprovado.

### 7. Produtos digitais futuros
- [x] Analisar e documentar oportunidades adequadas, como planilhas de controle financeiro, economia doméstica, planejadores de gastos, ferramentas complementares e materiais educativos.
- [x] Não implementar checkout, pagamentos ou assinaturas nesta etapa.

### 8. Search Console e Analytics
- [x] Documentar passos simples para Search Console, verificação de propriedade e envio do sitemap.
- [x] Documentar Analytics como opção; não inventar identificadores, nem ativar rastreamento sem configuração legítima e consentimento adequado.

### 9. Experiência e retenção
- [x] Melhorar navegação com recomendações de calculadoras relacionadas, ferramentas populares, categorias claras, busca funcional, conteúdo fácil de entender, resultados claros, experiência mobile e carregamento rápido, quando fizer sentido.
- [x] Não usar pop-ups invasivos, notificações insistentes ou mecanismos artificiais de retenção.

### 10. Custo zero e independência
- [x] Não introduzir hospedagem/API/banco de dados/IA pagos, assinaturas, dependências comerciais, publicação diária ou intervenção humana para executar cálculos.
- [x] Manter todas as calculadoras funcionais quando anúncios, afiliados e Analytics estiverem desativados; continuar publicável pelo GitHub Pages gratuito; não comprar domínio nem contratar serviço.

### 11. Auditoria, testes e publicação
- [x] Executar todos os testes matemáticos e testar todas as calculadoras, campos vazios, inválidos e valores decimais; verificar links internos, rotas inexistentes e 404, sitemap/robots, títulos/descrições/URLs, responsividade, geração completa do site e workflow de publicação.
- [x] Corrigir problemas encontrados; preservar funcionalidades atuais; não substituir o projeto por demonstração ou versão incompleta.
- [x] Atualizar o repositório público existente somente depois de validar geração, testes e workflow. Não mudar o endereço publicado nem ativar serviço pago.

### 12. Relatório final obrigatório
- [x] Entregar relatório objetivo informando: (1) quantidade final de calculadoras; (2) quantidade de páginas públicas; (3) melhorias de SEO; (4) palavras-chave por categoria e ferramenta; (5) perguntas frequentes exclusivas implementadas; (6) novas ferramentas e justificativas; (7) melhorias de velocidade e experiência mobile; (8) situação AdSense; (9) estrutura de afiliados; (10) página de patrocínios; (11) oportunidades de produtos digitais; (12) situação do sitemap e indexabilidade; (13) resultado dos testes; (14) pendências do proprietário; (15) endereço publicado; (16) confirmação de que nenhum serviço pago foi ativado.
- [x] Diferenciar claramente o que foi implementado, o que está preparado e o que ainda depende de aprovação ou configuração externa. Não prometer primeiro lugar no Google, aprovação AdSense ou faturamento; priorizar qualidade, originalidade, utilidade e sustentabilidade sem custo inicial ou manutenção diária.

## Estado da publicação

Endereço público do projeto: https://pedroicsan.github.io/calculafacil/. O repositório público existente é https://github.com/pedroicsan/calculafacil. O workflow `.github/workflows/pages.yml` executa os testes, gera o HTML estático com a origem e o caminho-base adequados e publica a atualização na branch principal. Nenhum domínio ou serviço pago foi ativado; credenciais e IDs de monetização continuam vazios até eventual configuração legítima pelo proprietário.
