# TODO — CalculaFácil

## 1. Calculadoras funcionais no navegador
- [x] Implementar todas as ferramentas obrigatórias e mostrar resultados instantâneos: calculadora de consumo de energia elétrica; calculadora de custo de combustível para viagens; comparador de preços por quilo, litro e unidade; calculadora de descontos e promoções; calculadora de porcentagem; calculadora de salário por hora; calculadora de divisão de despesas; calculadora de economia mensal; conversor de medidas; calculadora de custo de eletrodomésticos; calculadora de aumento e redução percentual; calculadora de juros simples; calculadora de custo de uma viagem; calculadora de economia entre produtos; calculadora de preço por quantidade.
- [x] Explicar cada cálculo de maneira simples. Não utilizar dados inventados; quando um cálculo depender de informações variáveis, permitir que o próprio visitante informe os valores.
- [x] Fazer os cálculos diretamente no navegador, sem depender de login, banco de dados, chamadas a modelos de IA, APIs externas ou intervenção humana para executá-los.

## 2. Portal, páginas e navegação
- [x] Criar página inicial com todas as ferramentas; uma página individual para cada calculadora; categorias de ferramentas; campo de pesquisa; seção de ferramentas populares; página Sobre; página de Contato; Política de Privacidade; e Termos de Uso.
- [x] Criar uma identidade visual própria, ícones e experiência intuitiva. Tornar o site rápido, responsivo e funcional em celulares.

## 3. Identidade e comunicação
- [x] Usar o nome CalculaFácil e o slogan “Ferramentas gratuitas para facilitar sua vida.”, com estética de portal de utilidades digitais profissional, confiável e amigável.
- [x] Preservar as cores: azul principal #1769AA; azul escuro #103B63; branco #FFFFFF; cinza claro #F4F6F8; verde #16865B para resultados positivos.

## 4. Autonomia, independência e custo zero
- [x] Não contratar serviços, comprar domínios, utilizar APIs pagas, contratar hospedagem, criar assinaturas ou implementar funcionalidades que gerem cobranças. Não sacrificar a gratuidade para adicionar funcionalidades desnecessárias.
- [x] Preferir site estático que funciona diretamente no navegador do visitante, sem chamadas a modelos de IA, APIs externas, banco de dados ou login. O projeto deve funcionar sozinho depois de construído e não exigir manutenção diária para executar os cálculos.
- [x] Não usar hospedagem WebDev paga ou baseada em consumo do Manus como dependência obrigatória. Priorizar hospedagem estática realmente gratuita, como GitHub Pages ou alternativa gratuita equivalente.
- [x] Entregar uma cópia completa dos arquivos-fonte, para que o usuário não fique preso a uma única plataforma. Se houver conta externa, preparação ou autorização manual, explicar exatamente o que o usuário deve fazer.
- [x] Fazer o funcionamento offline após o carregamento inicial quando possível, sem afirmar que a primeira visita funciona sem internet.

## 5. SEO, descoberta e conteúdo
- [x] Implementar URLs amigáveis; títulos e descrições exclusivos; sitemap XML; robots.txt; dados estruturados adequados; links internos entre ferramentas relacionadas; conteúdo explicativo original e específico em cada calculadora; boa velocidade; acessibilidade; experiência mobile.
- [x] Preparar integração futura com Google Search Console e Google Analytics sem inserir serviços pagos nem ativar rastreamento até haver identificadores válidos e decisão de configuração.

## 6. Monetização futura sem anúncios falsos
- [x] Preparar a estrutura para Google AdSense, links de afiliados e espaços publicitários identificados.
- [x] Não inserir anúncios falsos, não inventar aprovação do AdSense e não criar links de afiliados inexistentes. Deixar os espaços preparados para códigos legítimos após aprovação.
- [x] Garantir que o funcionamento das calculadoras não dependa de anúncios.

## 7. Verificação de qualidade
- [x] Testar individualmente todas as calculadoras e verificar resultados matemáticos, entradas inválidas, campos vazios, valores decimais, responsividade, navegação e velocidade.
- [x] Verificar funcionamento sem internet após o carregamento quando possível e corrigir problemas encontrados antes de considerar o projeto concluído.

## 8. Entrega e instruções
- [x] Entregar site completo e funcional, todas as calculadoras implementadas, identidade visual, SEO configurado e arquivos-fonte completos.
- [x] Preparar publicação em hospedagem gratuita se possível, sem ativar serviço pago.
- [x] Fornecer instruções para conectar um domínio futuramente caso o usuário decida comprar um; fornecer instruções para monetização; identificar eventuais etapas que ainda dependam do usuário.
- [x] Priorizar portal simples, funcional, rápido, útil e sustentável durante anos, sem assinaturas, servidores pagos ou créditos de inteligência artificial.

## Estado da publicação

O fluxo gratuito para GitHub Pages, a documentação e os passos de preparação foram implementados. O site ainda não foi publicado em uma conta externa: o proprietário precisa autorizar a criação/uso de um repositório público e ativar **Settings → Pages → GitHub Actions**. O GitHub Free exige repositório público para esse caso; código e site ficarão visíveis, e a documentação informa o registro técnico de IPs pelo provedor. Nenhum domínio foi comprado nem serviço pago ativado.
